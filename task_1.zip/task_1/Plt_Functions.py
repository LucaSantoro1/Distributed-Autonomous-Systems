""""
=========================================================================================================
                                DISTRIBUTED AUTONOMOUS SYSTEM 
=========================================================================================================
Group 11
Santoro Luca, 0001005415
Armando Spennato, 0001006172
Professor: Giuseppe Notarstefano   Tutor: Ivano Notarnicola  Tutor: Lorenzo Picherri
=========================================================================================================

In this file we implement all the needed functions for plots in the task 1.2: Centralized Training,
and task 1.3: Distibuted Training

=========================================================================================================
"""
import numpy as np 
import matplotlib.pyplot as plt

from sklearn.manifold import TSNE
import pandas as pd
import seaborn as sns
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay # To build and display the confusion matrix

import os # for saving

#########################################################################################################
""" *** TASK 1_2 *** """           # Centralized Training #
#########################################################################################################

##################
'''t_SNE Plot '''
##################
def T_SNE_plot(X,y,type):
 """
 ============================================================================================================
  Description: This function allows to show the t-distributed stochastic neighbor embedding (t-SNE) plot.
  It is a nonlinear dimensionality reduction technique to visualize data in a two or three dimensional space. 
  It is based on Stochastic Neighbor Embedding.
  We use this method in order to understand the distribution of our dataset. (DA CONTROLLARE)

      input:
                X --> Training data (60000,784)
                y --> label data (60000,784)
                type --> Parameter in order to select the needed plot
                
      output:  None
  ==============================================================================================================         
 """
 # is a tool for visualizing high-dimensional data.

 # t-SNE is consumes a LOT OF MEMORY so we use only a subset of our dataset. 

 X_train_subset = X[0:10000] 
 y_train_subset = y[0:10000]

 # Applying t - SNE on data 
 tsne = TSNE(n_components=2, verbose=1, random_state=123)
 z = tsne.fit_transform(X_train_subset)
 df = pd.DataFrame()
 df["y"] = y_train_subset
 df["comp-1"] = z[:,0]
 df["comp-2"] = z[:,1]
 #brief explanation of the parameter.
 #n_components (default: 2): Dimension of the embedded space.
 #verbose (default: 1) : Verbosity level.
 #perplexity (default: 30): The perplexity is related to the number of nearest neighbors that are used in other manifold learning algorithms. Consider selecting a value between 5 and 50.
 ##n_iter (default: 1000): Maximum number of iterations for the optimization. Should be at least 250.
 if type == 1:
   sns.scatterplot(x="comp-1", y="comp-2", hue=df.y.tolist(),
                    palette=sns.color_palette("hls", 10),
                    data=df).set(title="MNIST data T-SNE representation: ORIGINAL LABELS")
   print("\n*** t-SNE plot OK (1) ***")
 
 elif type == 2:
   sns.scatterplot(x="comp-1", y="comp-2", hue=df.y.tolist(),
                    palette=sns.color_palette("hls", 2),
                    data=df).set(title="MNIST data T-SNE representation: MODIFIED LABELS")
   print("\n*** t-SNE plot OK (2) ***")
 
 elif type == 3:
    sns.scatterplot(x="comp-1", y="comp-2", hue=df.y.tolist(),
                    palette=sns.color_palette("hls", 2),
                    data=df).set(title="MNIST data T-SNE representation: BALANCED DATASET")
    print("\n*** t-SNE plot OK (3) ***")
 else: 
    print("ERROR: Wrong type value")

 return None

####################################
''' Histogram Pixel Distribution '''
####################################

def histogram_plot(X,y):

  """
  =================================================================================================================
   Description: Whit this function we plot two images of the dataset with the associated histograms in order to see
   the density of the white and black pixels that define our images.
      input:
                X --> Training data (60000,28,28)
                y --> label data (60000,784)
      output:  None
  ==================================================================================================================         
 """
  x_train_reshape = X.reshape(60000, 784) # We need to reshape the data in order to build the histogram
  # to have a range from 0 to 1 instead of 0 to 255
  #Normalization
  # We change the dType as float 
  x_train_reshape = x_train_reshape.astype('float32')
  # We devide each data that has a value in the range [0,255] by 255 
  x_train_reshape /= 255
  
  
  plt.subplot(2, 2, 1)

  plt.imshow(X[0], cmap=plt.get_cmap('gray'))

  plt.subplot(2, 2, 2)

  plt.hist(x_train_reshape[0])
  plt.title("Digit: {}".format(y[0]))

  plt.subplot(2, 2, 3)
  plt.imshow(X[3], cmap=plt.get_cmap('gray')) 

  plt.subplot(2, 2, 4)

  plt.hist(x_train_reshape[3])
  plt.title("Digit: {}".format(y[3]))

  plt.subplots_adjust(left=0.125, # In order to define distances in the subplot
                    bottom=0.1, 
                    right=0.9, 
                    top=0.9, 
                    wspace=0.2, 
                    hspace=0.35)

  return None


######################
'''Confusion Matrix'''
######################

def confusion_matrix_plot(y_test_blc,prediction):
  '''
  =========================================================================================
  Description: With this function we are able to generate and to show the confusion matrix. 
  One of the metrics used in our project to evaluate the performance of the NN.
            
            input: y_test_blc --> true labels
                   prediction --> list in which there are all the predicted label of the NN
            output: None, the function return the plot of the confusion matrix
  =========================================================================================
  '''

  '''
  #Less details inside the matrix
  cf_matrix = confusion_matrix(y_test_blc,prediction)

  # Plot the confusion matrix using seaborn and matplotlib
  sns.heatmap(cf_matrix, annot=True, fmt='g', cmap='Blues', cbar=True,
            xticklabels=['Predicted 0', 'Predicted 1'],
            yticklabels=['Actual 0', 'Actual 1'])

  plt.xlabel('Predicted label')
  plt.ylabel('True label')
  plt.title('Confusion Matrix')
  plt.show()
  '''

  # More details
  cf_matrix = confusion_matrix(y_test_blc,prediction)
  group_names = ['True Neg','False Pos','False Neg','True Pos']

  group_counts = ["{0:0.0f}".format(value) for value in
                cf_matrix.flatten()]
  group_percentages = ["{0:.2%}".format(value) for value in
                     cf_matrix.flatten()/np.sum(cf_matrix)]
  labels = [f"{v1}\n{v2}\n{v3}" for v1, v2, v3 in
          zip(group_names,group_counts,group_percentages)]
  labels = np.asarray(labels).reshape(2,2)
  sns.heatmap(cf_matrix, annot=labels, fmt="", cmap='Blues')
  plt.xlabel('Predicted label')
  plt.ylabel('True label')
  plt.title('Confusion Matrix')
  
  
  return None


####################################
''' wrong classified digit plot '''
####################################
# To plot the first 10 wrong predicted labels
def wrong_classified_digits_plot(X_test_blc,y_test_blc,missclass_indexes,prediction):
  '''
  This function allows display 10 of the misclassified images using Matplotlib library.
                input : X_test_blc
                        y_test_blc
                        missclass_indexes
                        prediction

                output --> None,plot
  '''
  # display the 10 wrong classifications
  fig, axs = plt.subplots(2, 5,figsize=(12, 6))
  axs = axs.flat
  for i in range(10):
      if i < len(missclass_indexes):
          axs[i].imshow(X_test_blc[missclass_indexes[i]].reshape(28,28), cmap='gray') # X_test_blc + reshape perchè mi serve  28x28
          axs[i].set_title("True Label: {}\nPredicted Label: {}".format(y_test_blc[missclass_indexes[i]],
                                                     prediction[missclass_indexes[i]]))
          axs[i].axis('off')

  plt.suptitle('Wrong Digits Classification')
  
 
  return None


###################################################################################################

#########################################################################################################
""" *** TASK 1_3 *** """           # Distibuted Training #
#########################################################################################################

######################
'''Confusion Matrix'''
######################
# Same as the previous one 
####################################
''' wrong classified digit plot '''
####################################
# Same as the previous one 