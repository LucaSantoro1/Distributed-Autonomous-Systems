""""
=========================================================================================================
                                  DISTRIBUTED AUTONOMOUS SYSTEM
=========================================================================================================
Group 11
Santoro Luca, 0001005415
Spennato Armando, 0001006172

Professor: Giuseppe Notarstefano   Tutor: Ivano Notarnicola  Tutor: Lorenzo Picherri
=========================================================================================================
                        TASK 1: Distributed Classification via Neural Networks
=========================================================================================================
"""

# we need to import the following Python Standard Libraries that contain the syntax, semantics, and tokens of
# Python which we need to accomplish the task.
from Functions import*
from Plt_Functions import*

import matplotlib.pyplot as plt
import numpy as np
from keras.datasets import mnist # To import our Dataset
from imblearn.under_sampling import RandomUnderSampler # For Balancing
from sklearn.model_selection import train_test_split   # For Shuffling
#from sklearn.utils import shuffle

from sklearn.metrics import precision_score, accuracy_score       # To find the precision and accuracy of our NN
from imblearn.metrics import sensitivity_score, specificity_score # To find the sensitivity and specificity of our NN

from tabulate import tabulate # per stampare i dati a terminale in forma tabulare (maniera più elegante per presentare i dati )

import random
random.seed(42)
np.random.seed(42)

from collections import Counter

from termcolor import colored # to change the characteristics of the terminal cost
##########################################################################

print(colored('\n-------------------------------------------------------------------------------------\n','red',attrs=['bold']))
print(colored('\n*** TASK 1: CLASSIFICATION VIA NEURAL NETWORK ***\n','red',attrs=['bold']))
print(colored('\n*** TASK 1.2: CENTRALIZED TRAINING ***\n','red',attrs=['bold']))


''' ----> *** Simulation saving *** <----'''
specified_subfolder = "Task 1.2"
folder_path = SaveSimulation(specified_subfolder, None)

####################################################################################
'''Section 1: SIMULATION FLAGS AND PARAMETERS'''
###################################################################################

select_digit = 4 # To be able to select a digit (from 0 to 9)

'''%%%% SIMULATION FLAGS %%%%'''
# Plot flags
image_MNIST= True
t_SNE_plot = True # in order to visualize the t-SNE plot in different situation  
histo_plot = True

confusion_matrix_flag = True
wrong_classified_digits = True

'''%%%% SET UP/PARAMETERS NEURAL METWORK %%%%'''

d = [784,64,1] # Number of neurons in each layer.

# Note: As in the report notation:
# d_c indicates the number of neuron of the current layer
# d_n indicate the number of neurons in the next layer

T = len(d) # Total number of Layers of our neural network

############################
# Gradient Method Parameters
############################
MAX_EPOCHS = 50 # Ephochs
batch_size = 32
step_size = 0.1 #1e-2 # Learning rate (Gradient Method)


####################################################################################
'''section 2: IMPORT AND PRE-PROCESSING OF DATASET'''
####################################################################################
# LOADING the Mnist Dataset
(X_train, y_train), (X_test, y_test) = mnist.load_data()

X_hist = X_train # We define this vector in order
# to call the histogram_function, useful only for a graphical rapresentation.

# We show the DIMENSIONS of the data obtained from MNIST
print(colored('\n*** INITIAL DATA DIMENSIONS ***\n','green',attrs=['bold']))
print('X_train: ' + str(X_train.shape))
print('y_train: ' + str(y_train.shape))
print('X_test:  ' + str(X_test.shape))
print('y_test:  ' + str(y_test.shape))
# We can see that there are 60k images in the training set and 10k images in the testing set.
# The dimension of our training vector is (60000, 28, 28),
# this is because there are 60k grayscale images with the dimension 28X28

# We show the MNIST dataset IMAGES 
if image_MNIST == True:
 for i in range(9):  # We build an example of 3x3 images from MNIST
     plt.subplot(330 + 1 + i)
     plt.imshow(X_train[i], cmap=plt.get_cmap('gray'))
     
 filename = 'Fig.1 Image_MNIST.png'
 filepath = os.path.join(folder_path, filename)
 plt.savefig(filepath,bbox_inches='tight', pad_inches=0.1)
    
 plt.show()

# We reshape the initial matrix data [28x28] in a vector of dimension [784×1] in order to provide the correct
# dimension of the inputs of our neural network.
# MNIST is a three-dimensional data, we'll reshape it into the two-dimensional one.
X_train = X_train.reshape(60000, 784)
X_test = X_test.reshape(10000, 784)

# We show the NEW DIMENSIONS of the RESHAPED data
print(colored('\n*** RESHAPED DATA DIMENSIONS ***\n','green',attrs=['bold']))
print('X_train: ' + str(X_train.shape))
print('X_test: ' + str(X_test.shape))

###############
# NORMALIZATION
###############
# The data in the training set and test set have a discrete value between 0 and 255,
# that represent the gray scale pixel values. Normalizing these pixel values between
# 0 and 1 helps in speeding up the training. Since we are going to use stochastic gradient
# descent, normalizing data will also help in reducing the chance of getting stuck in local optima.
# To normalize the data, we represent it as float type and divide it by 255 as shown
# in the following code:

# We change the dType as float
X_train = X_train.astype('float32')
X_test = X_test.astype('float32')

# We devide each data that has a value in the range [0,255] by 255
X_train /= 255
X_test /= 255

# Now we examine our normalized data plotting two images with the relative histograms in order to see
# the density of the white and black pixels that define our images.
# In particular we have chosen the digit 1 and the digit 5.

if histo_plot == True:
 histogram_plot(X_hist,y_train)
 filename = 'Fig.2 Histogram.png'
 filepath = os.path.join(folder_path, filename)
 plt.savefig(filepath,bbox_inches='tight', pad_inches=0.1)
 plt.show()

# As a result we can notice that we have an higher density of points that are close to zero, these represents
# the black pixels of our images. Instead, the rest of the grey scale points that are close to 1, so to white color, 
# represent the digit. Looking better the two histograms we can notice the little differnce in the distribution of the white pixels, 
# in particular we can undestand that for digit 1 less white pixels are necessary.

'''t-SNE'''  

# Now we exploit the t-distributed stochastic neighbor embedding. t-SNE is a machine learning tecnique for the dimensionality reduction.
# In particular it is suitable for the visualization of high-dimensional data sets. So, since we deal with high dimension data this plot is useful 
# to understand the distribution of our dataset.

# t-SNE consumes a lot of memory, so we in the function only a subset of our dataset. 

if t_SNE_plot == True:
 print(colored('\n*** t-SNE (Type=1) ***\n','white',attrs=['bold']))
 T_SNE_plot(X_train, y_train,1)
 filename = 'Fig.3 TSNE_Original_Labels.png'
 filepath = os.path.join(folder_path, filename)
 plt.savefig(filepath,bbox_inches='tight', pad_inches=0.1)
 plt.show()

###################################
''' DATA BALANCING'''
###################################

# Since we need to assign labels 0 and 1, we need to change the dtype of the data
# contained in the arrays y_train and y_set, labels array
y_train = y_train.astype('int32')
y_test = y_test.astype('int32')

# Associate 0 to data which NOT represent the number we want to classify

for i in range(0, len(y_train)):
    if y_train[i] == select_digit:
        y_train[i] = 1
    else:
        y_train[i] = 0

for i in range(0, len(y_test)):
    if y_test[i] == select_digit:
        y_test[i] = 1
    else:
        y_test[i] = 0

print(colored('\n*** LABELS CHANGED ***\n','green',attrs=['bold']))
print(f'The labels are:\t{np.unique(y_test)}')

'''t-SNE'''
# for comparison with the previus one 
if t_SNE_plot == True:
 print(colored('\n*** t-SNE (Type=2) ***\n','white',attrs=['bold']))
 T_SNE_plot(X_train, y_train,2)
 filename = 'Fig.4 TSNE_Modified_Labels.png'
 filepath = os.path.join(folder_path, filename)
 plt.savefig(filepath,bbox_inches='tight', pad_inches=0.1)
 plt.show()

# BALANCING:
# Due to the previous manipulation our training set is not balanced (we can also see it from the t-SNE plot), because
# the class related to the label 0 is a MAJORITY CLASS while the one related to the label 1 is a MINORITY CLASS.

# There are different tecniques to obtain balanced dataset. We exploit the UNDERSAMPLING technique, which remove examples
# from the training dataset that belong to the Majority class in order to better balance the class distribution.
# In this way we are able to obtain a better training of the machine learning model.

RandomUS = RandomUnderSampler()
X_train_blc, y_train_blc = RandomUS.fit_resample(X_train, y_train)
X_test_blc, y_test_blc = RandomUS.fit_resample(X_test, y_test)

print(colored('\n*** DATA BALANCED ***\n','green',attrs=['bold']))
 
## t_SNE plot Balanced Dataset
if t_SNE_plot == True:
     print(colored('\n*** t-SNE (Type=3) ***\n','white',attrs=['bold']))
     T_SNE_plot(X_train_blc,y_train_blc,3)
     filename = 'Fig.5 TSNE_Balanced_Dataset.png'
     filepath = os.path.join(folder_path, filename)
     plt.savefig(filepath,bbox_inches='tight', pad_inches=0.1)
     plt.show()

print(np.shape(X_train_blc))
print(np.shape(y_train_blc))


# Shuffling the train and the test set

X_train_blc,_,y_train_blc,_= train_test_split(X_train_blc, y_train_blc)
X_test_blc,_,y_test_blc,_= train_test_split(X_test_blc, y_test_blc)



if True:
    print('Resampled dataset shape %s' %Counter(y_train_blc))
    print(np.shape(X_train_blc))
    print(np.shape(y_train_blc))

print(colored('\n*** ALL DATA AND LABELS ARE READY TO BE ELABORATED ***\n','blue',attrs=['bold']))

#####################################################################################################
# Task 1.2: implement the multi-sample neural network,
# extending the one-sample example presented during the lectures, with sigmoid as activation function 
# and BCE as loss function
######################################################################################################
######################
''' INITIALIZATION '''
######################

# Initial weights (in machine learning scenario)/ initial input trajectory (in optimal control scenario)
# Initialization way 1
# uu = [ (1e-1)*np.random.randn(d[iidx+1],d[iidx]+1) for iidx in range(T-1)]

# Initialization way2 (Better) :
uu = [np.random.randn(d[l_idx+1], d[l_idx]+1) * np.sqrt(1/(d[l_idx]+d[l_idx+1])) for l_idx in range(T-1)] # initialization di Xavier/Glorot
# This initialization is designed to work well with common activation function such as Sigmoid and Hyperbolic tangent.

JJ=np.zeros(MAX_EPOCHS)
NormGradJ = np.zeros(MAX_EPOCHS) 
##################################################################################
""" Dataset Reduction """
##################################################################################
# For the training and testing of the NN we select only a reduced subset of images:
""" Train """
DIM_TRAIN = 1000 # number of data-label for NN train
X_train_blc = X_train_blc [0:DIM_TRAIN]
y_train_blc = y_train_blc [0:DIM_TRAIN]
""" Test """
DIM_TEST = 500 # number of data-label for NN test
X_test_blc = X_test_blc [0:DIM_TEST]
y_test_blc = y_test_blc [0:DIM_TEST]
###################################################################################
#################
'''TRAINING'''
#################
print(colored('\n*** TRAINING ***\n','green',attrs=['bold']))

SIZE_X_train_blc = len(X_train_blc) # number of train data
N_batches=int(SIZE_X_train_blc/batch_size) # number of necessary batch  ( we devide the number of train data in groups of 32 elements)

for epoch in range(MAX_EPOCHS):   # Epochs
  for batch_count in range(N_batches): # Batch
    
    DELTA_batch = [np.zeros_like(index) for index in uu]  # Gradient initialization
    # we create a list of arrays filled with zeros, where each array has the same shape and data type as the corresponding array
    # in the list uu. This is achieved using the NumPy function numpy.zeros_like().
    
    for batch_el in range (batch_size): # For each element of the batch
      img=batch_count*batch_size+batch_el # we need this index to select the image inside the single batch (0...31,32...63 ecc)

      xx = FORWARD_pass(uu,X_train_blc[img],T) # all signals (we fill xx)

      ########
      # loss
      ########
      loss, Grad_loss = BCE(xx[-1][0], y_train_blc[img]) 
      # with xx[-1][0] we log in to the first element of the last xx element,so xT the output of our NN.
      # Grad_loss:terminal coefficient of the costate.

      # BACKWARD PASS
      _, grads = BACKWARD_pass(xx, uu, Grad_loss,T) 
      # grads: gradients of J wrt u
      # it contains T-1 elements, each one has a shape equal to an element of uu.

      # we update in backward the gradient of each layer, 
      # in this way we take into account for each layer the gradient of the next layers
      for l in reversed(range(T-1)):
          DELTA_batch[l] += grads[l] / batch_size 
          # We normalize the gradient on the batch dimension for a better updates' consistency.

      # loss accumulation (for plots) 
      JJ[epoch] += loss #/ SIZE_X_train_blc # averaging the loss over all sample point
      # grad loss accumulation
      for l in range(T-1):
        # we update the normGrad along the epoch considering all the norm of gradients of each layer
        NormGradJ[epoch]+= np.linalg.norm(DELTA_batch[l])

    # gradient algorithm
    for l in range(T-1):
      # we update the weights of each layer l
      uu[l] = uu[l] - step_size*DELTA_batch[l]

  if epoch % 1 == 0:
        print(f'Iteration n° {epoch+1:d}: loss = {JJ[epoch]:.4f}, Grad_loss = {NormGradJ[epoch]:.4f}')


print()
print("Training complete!")
print()

#############
'''TESTING'''
#############
print(colored('\n*** TESTING ***\n','green',attrs=['bold']))

print("Evaluation of the network:\n")

# After training, the model is evaluated using some metrics.
# The metrics to be computed strongly depend on the nature of the model output.
# So since we are deal with a classification (or a discrete variable) the Confusion matrix, 
# Precision, Accuracy, Sensitivity and Specificity can be used.


SIZE_X_test_blc= len(X_test_blc ) 
prediction = [] # to store the output of our NN
for img in range(SIZE_X_test_blc):
  prediction.append(round(FORWARD_pass(uu, X_test_blc[img],T)[-1][0]))

missclass_indexes = [] # to store the indexes where we have a wrong prediction
for indice, (element1, element2) in enumerate(zip(y_test_blc, prediction)):  # zip unisco (,) # enumerate "conto le coppie"
  if element1 != element2:
      missclass_indexes.append(indice)

goodclass_indexes = [] # to store the indexes where we have a true prediction
for indice, (element1, element2) in enumerate(zip(y_test_blc, prediction)):  
  if element1 == element2:
      goodclass_indexes.append(indice)


######################
'''Confusion matrix'''
######################

# A Confusion matrix in general is an N × N matrix used for evaluating the performance of a classification model, where N is the
# number of target classes. Since we deal with a binary classifier N = 2. The matrix compares the actual target values with those predicted by
# the machine learning model. The confusion matrix provides a detailed insight of how the model performs and which kind of error it makes.
# It is a tabular summary of the number of correct and incorrect predictions made by a classifier.
# Confusion matrices are widely used because they give a better idea of a model’s performance than
# classification accuracy does. For example,in classification accuracy, there is no information about
# the number of misclassified instances.

if confusion_matrix_flag == True:
    confusion_matrix_plot(y_test_blc,prediction)
    filename = 'Fig.6 Confusion_Matrix.png'
    filepath = os.path.join(folder_path, filename)
    plt.savefig(filepath,bbox_inches='tight', pad_inches=0.1)
    plt.show()
    
##############
'''Metrics'''
##############
''' Accuracy '''               # Measures how often the classifier makes the correct prediction.
''' Misclassification rate ''' # Tell us the percentage of observations that were incorrectly predicted by a classification model
''' Precision '''   # It tells us how many predictions are actually positive out of all the total positive predicted
''' Sensitivity ''' # The percentage of positive outcomes the model is able to detect
''' Specificity ''' # The percentage of negative outcomes the model is able to detect

##################################
# Table to show the metrics value
##################################

pred_array = np.array(prediction) 
Accuracy = accuracy_score(y_test_blc, pred_array) 
precision = precision_score(y_test_blc, pred_array)
sensitivity = sensitivity_score(y_test_blc, pred_array)
specificity = specificity_score (y_test_blc, pred_array)

table = [["Accuracy",round(Accuracy*100,2)],
 ["Misclassification Rate",round((len(missclass_indexes)/len(prediction))*100,2)],
  ["Precision",round(precision*100,2)],["Sensitivity",round(sensitivity*100,2)],
   ["Specificity",round(specificity*100,2)]]

print(tabulate(table, headers=["Metric","Value(%)"],tablefmt="pretty"))

print (f'\nNumber of Goodclass: {len(goodclass_indexes)}   Number of Missclass: {len(missclass_indexes)}\n')#



################################
'''Plot missclassified digits'''
################################

# It is good choice display model outputs. In case of classification, the misclassified samples 
# are often displayed to gain insight into the types of mistakes that the model is making. So let’s display 
# 10 of the misclassified images using Matplotlib library:

if wrong_classified_digits == True:
  wrong_classified_digits_plot(X_test_blc,y_test_blc,missclass_indexes,prediction)
  filename = 'Fig.7 Wrong_Classified_digits.png'
  filepath = os.path.join(folder_path, filename)
  plt.savefig(filepath,bbox_inches='tight', pad_inches=0.1)
  #plt.show()

###################
''' Plots '''
##################
# cost function evolution
plt.figure()
plt.title('Cost Function Evolution')
plt.semilogy(JJ, label='Cost Evolution', linewidth = 3,color='red')
plt.xlabel("Epochs")
plt.ylabel("J")
plt.legend()
plt.grid()
filename = 'Fig.8 Cost_Function_Evolution.png'
filepath = os.path.join(folder_path, filename)
plt.savefig(filepath,bbox_inches='tight', pad_inches=0.1)
plt.show()

# norm of the gradient
plt.figure()
plt.title('Norm of the Cost Function Gradient Evolution')
plt.semilogy(NormGradJ, label='Total Gradient Evolution', linewidth = 3,color='green')
plt.xlabel("Epochs")
plt.ylabel(r"$||\Delta u_t||_2$")
plt.legend()
plt.grid()
filename = 'Fig.9 Norm_of_the_Cost_Function_Gradient_Evolution.png'
filepath = os.path.join(folder_path, filename)
plt.savefig(filepath,bbox_inches='tight', pad_inches=0.1)
plt.show()


####################################
'''Simulation parameters file txt'''
####################################

# We save a file with all simulation parameters
filepath = os.path.join(folder_path)
f = open(f"{filepath}/Simulation_Params.txt","a")
f.write(f"MAX_EPOCHS = {MAX_EPOCHS}\n")
f.write(f"batch_size = {batch_size}\n")
f.write(f"DIM_TRAIN = {DIM_TRAIN}\n")
f.write(f"DIM_TEST = {DIM_TEST}\n")
f.write(f"step_size = {step_size}\n")
f.close()

###################################
'''Metrics file'''
###################################

table = tabulate(table, headers=["Metric", "Value(%)"], tablefmt="pretty")
additional_info = f'\nNumber of Goodclass: {len(goodclass_indexes)}   Number of Missclass: {len(missclass_indexes)}\n'
# Write to a text file
filepath = os.path.join(folder_path)
with open(f"{filepath}/Evaluation_metrics.txt","a") as file:
    file.write(table)
    file.write(additional_info)


