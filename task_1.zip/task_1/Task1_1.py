""""
=========================================================================================================
                         			DISTRIBUTED AUTONOMOUS SYSTEM
=========================================================================================================
Group 11
Santoro Luca, 0001005415
Spennato Armando, 0001006172

Professor: Giuseppe Notarstefano   Tutor: Ivano Notarnicola  Tutor: Lorenzo Picherri
=========================================================================================================
                        TASK 1: Distributed Classification via Neural Networks
=========================================================================================================
"""
from Functions import*

import numpy as np
import networkx as nx # package library needed to define graph
import matplotlib.pyplot as plt

import scipy.linalg # used int the vectorial implementation
from termcolor import colored # to change the characteristics of the terminal cost

# We sets the seed for the random number generator, in both the random and numpy.random modules, which
# can be useful for testing and debugging purposes, as well as for ensuring reproducibility of results.
import random
np.random.seed(0)
random.seed(0)

################################################################################################################################
print(colored('\n-------------------------------------------------------------------------------------\n','red',attrs=['bold']))
print(colored('\n*** TASK 1: CLASSIFICATION VIA NEURAL NETWORK ***\n','red',attrs=['bold']))
print(colored('\n*** TASK 1.1: DISTRIBUTED OPTIMIZATION ***\n','red',attrs=['bold']))
#################################################################################################################################

###########
'''FLAGS'''
###########
Flag_erG = False # Random graph, Erdős-Rényi graph or a binomial graph
Flag_pathG = False
Flag_starG = False 
Flag_cycleG = True
Flag_completeG = False

diminishing = True

show_G = True # To visualize the graph

euristic_weights= False # to choose the weights
M_H_weights= True

################
'''PARAMETERS'''
################
# Useful constants

NN = 10 # number of node
dd=2 # dimetion R^2
I_NN = np.eye(NN) 

p_ER=0.5

MAXITERS = int(1e3) # Explicit Casting, maximum number of iteration

#############
'''GRAPHS'''
#############
print(colored('\n*** GRAPH ***\n','green',attrs=['bold']))

''' -> BINOMIAL graph <- '''
if Flag_erG:
 # Create a Binomial Graph with N nodes
 graph_type = "Binomial"
 G = nx.binomial_graph(NN,p_ER) 
 print(colored('\nChosen graph: BINOMIAL GRAPH\n','green',attrs=['bold']))

''' -> PATH graph <- '''
if Flag_pathG:
 # Create a Path Graph with N nodes
 graph_type = "Path"
 print(colored('\nChosen graph: PATH GRAPH\n','green',attrs=['bold']))
 G = nx.path_graph(NN) # we obtain a path graph with N nodes

''' -> STAR graph <- '''
if Flag_starG:
 # Create a Star Graph with N nodes
 graph_type = "Star"
 print(colored('\nChosen graph: STAR GRAPH\n','green',attrs=['bold']))
 G = nx.star_graph(NN-1) 

''' -> CYCLIC graph <- '''
if Flag_cycleG:
 # Create a Cycle Graph with N nodes
 graph_type = "Cycle"
 print(colored('\nChosen graph: CYCLE GRAPH\n','green',attrs=['bold']))
 G = nx.cycle_graph(NN)

''' -> COMPLETE graph <- '''
if Flag_completeG:
 # Create a Complete Graph with N nodes
 graph_type = "Complete"
 print(colored('\nChosen graph: COMPLETE GRAPH\n','green',attrs=['bold']))
 G = nx.complete_graph(NN)

''' ----> *** Simulation saving *** <----'''

specified_subfolder = "Task 1.1"
folder_path = SaveSimulation(specified_subfolder, graph_type)

'''----> *** Graph drawing *** <----'''
if show_G:
 fig1 = plt.figure()
 plt.title(r"Graph")
 nx.draw(G, with_labels = True)

 filename = 'Fig.1 Graph.png'
 filepath = os.path.join(folder_path, filename)
 plt.savefig(filepath,bbox_inches='tight', pad_inches=0.1)

while True:
	# we extract the adj matrix
	Adj = nx.adjacency_matrix(G).toarray() # Adjacency matrix of a graph
	degree = np.sum(Adj, axis=0) 
	
	# we check connectivity
	# algebraic test which is related to the power of the adj matrix , to chech if a matrix is associated
	# to a connected graph (we want to work with a connected graph)
	test = np.linalg.matrix_power(Adj+I_NN,NN) # n x n matrix
	if np.all(test>0):
		print('The graph is connected\n')
		break
	else:
		print('The graph is NOT connected')
		print('--------------------------')
		print('Try again:\n')

# To see the Adj Matrix
if True:
  print(f'Adjacency matrix graph:\n {Adj}')
  print(f'Degree:\n{degree}')

##############
'''WEIGHTS'''
##############
print(colored('\n*** WEIGHTS ***\n','green',attrs=['bold']))
##################

if euristic_weights:
	print(colored('\nChosen weights: EURISTIC WEIGHTS\n','green',attrs=['bold']))
	threshold = 1e-15
	WW = 1.5*I_NN + 0.5*Adj

	ONES = np.ones((NN,NN))
	ZEROS = np.zeros((NN,NN))
	WW = np.abs(WW)

	while any(abs(np.sum(WW,axis=1)-1) > threshold):
		WW = WW/(WW@ONES) # row (necessary for consensus)
		WW = WW/(ONES@WW) # col, if we lose column stochasticity we reach consensus but not to the average of the initial value
		WW = np.maximum(WW,0*ONES)

###################
if M_H_weights:
 print(colored('\nChosen weights: Metropolis-Hastings Weights\n','green',attrs=['bold']))

 WW = np.zeros((NN,NN))
 for ii in range(NN):
    #Nii = list(G.neighbors(ii))
    Nii = np.nonzero(Adj[ii])[0]

    for jj in Nii:
       #WW[ii,jj] = 1/(1+max(degree[ii],degree[jj]))
       WW[ii,jj] = 1/(1+np.max([degree[ii],degree[jj]]))

    WW[ii,ii] = 1-np.sum(WW[ii,:])
#######################
# To see the Weighted Adj Matrix
if 1:
	print(colored('\nWeighted Adjiacency matrix\n','green',attrs=['bold']))
	print(f'WW:\n{WW}')


with np.printoptions(precision=4, suppress=True):
		   print('\nCheck Stochasticity:\n row: {} \n column {}'.format(
  	   np.sum(WW,axis=1),
		   np.sum(WW,axis=0)
	     ))
#######################


######################################################
'''Declare Cost Variables (local cost function)'''
######################################################
# An important assumption for both DG algorithm and GT algorithm is the convexity of the cost function:
# to have a convex cost function we need to have Q positive definite.

Q = 10*np.zeros((NN,dd,dd)) # positive definite
for ii in range(NN):
		T = scipy.linalg.orth(np.random.rand(dd,dd))
		D = np.diag(np.random.rand(dd))*10
		Q[ii] = T.T@D@T
		if True:
			print(np.linalg.eigvals(Q[ii])) # To see the eigenvalues of the matrix Q

R = 10*(np.random.rand(NN,dd)-1)

# Compute Optimal Solution
Q_centr = np.sum(Q,axis=0)
R_centr = np.sum(R,axis=0)

# To compute the centralized solution, to compute the optimal u (just for comparison)
u_opt = -np.linalg.inv(Q_centr)@R_centr
Jopt = 0.5*u_opt@Q_centr@u_opt+R_centr@u_opt
print('\nThe optimal cost is: {:.4f}\n'.format(Jopt))

############################
'''DISTIBUTED ALGORITHMS '''
############################
print(colored('\n***DISTRIBUTED ALGORITHMS***\n','green',attrs=['bold']))
# Declare Algorithmic Variables
# we define two type of uu because we want to compare the uu for the gradient
# tracking with the uu for the distributed gradient

uu = np.zeros((NN,MAXITERS,dd))
uu_dg = np.zeros((NN,MAXITERS,dd)) # distributed gradient
YY = np.zeros((NN,MAXITERS,dd)) # auxiliary variable for the gradient tracking (Stack of s_i^k)

##################
# Initialization #
##################

# we chose an initial condition and we initialize the two algorithm at the same initial u
uu_init = 10*np.random.rand(NN,dd)
uu[:,0] = uu_init  # : means all the agents, 0 means the first time iteration of the algorithms
uu_dg[:,0] = uu_init

# necessary step for the Gradient tracking algorithm (s_i^0 at time initialized = \nabla J_i(u_i^0))
# u_i^0 is free as seen in the slide
for ii in range (NN):
	_, YY[ii,0] = quadratic_fn(uu[ii,0],Q[ii],R[ii]) # to find the gradient we consider only the second argument,
	                                                # we can observe that the gradient is evaluated to u_i^0

JJ = np.zeros((MAXITERS))
JJ_dg = np.zeros((MAXITERS))

innovation = np.zeros((NN,MAXITERS,dd))#

################
# *** MAIN *** #
################

ss = 1e-2 # stepsize

for kk in range (MAXITERS-1):
	if (kk % 50) == 0:
		print("Iteration {:3d}".format(kk), end="\n")

	for ii in range (NN):
		# Gradient Tracking
		Nii = np.nonzero(Adj[ii])[0]

		uu[ii,kk+1] = WW[ii,ii]*uu[ii,kk] - ss*YY[ii,kk]
		for jj in Nii:
			uu[ii,kk+1] += WW[ii,jj]*uu[jj,kk]

		J_ii, grad_J_ii = quadratic_fn(uu[ii,kk],Q[ii],R[ii])
		_, grad_J_ii_p = quadratic_fn(uu[ii,kk+1],Q[ii],R[ii])

		YY[ii,kk+1] = WW[ii,ii]*YY[ii,kk] +(grad_J_ii_p-grad_J_ii)
		innovation[ii,kk] = grad_J_ii_p-grad_J_ii#

		for jj in Nii:
			YY[ii,kk+1] += WW[ii,jj]*YY[jj,kk]

		JJ[kk] +=J_ii
		

		# Distributed Gradient for Comparison
		J_ii_dg, grad_J_ii_dg = quadratic_fn(uu_dg[ii,kk],Q[ii],R[ii])
		JJ_dg[kk] +=J_ii_dg

		if diminishing:
			uu_dg[ii,kk+1] = WW[ii,ii]*uu_dg[ii,kk] - ss*grad_J_ii_dg/(kk+1)*10 # diminishing
		else:
			uu_dg[ii,kk+1] = WW[ii,ii]*uu_dg[ii,kk] - ss*grad_J_ii_dg
		
		for jj in Nii:
			uu_dg[ii,kk+1] += WW[ii,jj]*uu_dg[jj,kk]

# Terminal iteration
for ii in range (NN):
 J_ii, grad_J_ii = quadratic_fn(uu[ii,-2],Q[ii],R[ii])
 _, grad_J_ii_p = quadratic_fn(uu[ii,-1],Q[ii],R[ii]) #
 JJ[-1] += J_ii
 J_ii_dg, _ = quadratic_fn(uu_dg[ii,-1],Q[ii],R[ii])
 JJ_dg[-1] += J_ii_dg
 innovation [ii,-1]+= grad_J_ii_p-grad_J_ii #


###############################
""" Compute consensus error """
###############################
uu_avg = np.mean(uu, axis=0) # shape (ITERS, dd)
uu_avg_dg = np.mean(uu_dg, axis = 0)

" Using Distributed Gradient tracking method "
EE = np.sum(
    np.linalg.norm(
        uu - uu_avg,
        axis=2), # norm ||.||_R^d
    axis=0) # sum over i

" Using Distributed Gradient method "
EE_dg = np.sum(
    np.linalg.norm(
        uu_dg - uu_avg_dg,
        axis=2), # norm ||.||_R^d
    axis=0) # sum over i

print(colored('\n-------------------------------------------------------------------------------------\n','red',attrs=['bold']))
####################################################################################
''' Figure 2 : Evolution of the Consensus Error (DISTRIBUTED GRADIENT TRACKING ALGORITHM
VS DISTRIBUTED GRADIENT ALGORITHM) '''
####################################################################################

if True:
	plt.figure(figsize=(8,6))
	plt.semilogy(np.arange(MAXITERS), EE, '--', linewidth=3,label= 'EE_GT')
	plt.semilogy(np.arange(MAXITERS), EE_dg, '--', linewidth=3,label = 'EE_DG')
	plt.xlabel(r"iterations $k$")
	plt.ylabel(r"$\sum_{i=1}^N \|u_i^k - \bar{u}^k\|$")
	plt.title(r"Evolution of the Consensus Error")
	plt.legend()
	plt.grid()

	filename = 'Fig.2 Evolution of the Consensus Error.png'
	filepath = os.path.join(folder_path, filename)
	plt.savefig(filepath,bbox_inches='tight', pad_inches=0.1)

# *** COMMENT FIGURE (Evolution of the Consensus Error (DISTRIBUTED GRADIENT TRACKING ALGORITHM
# VS DISTRIBUTED GRADIENT ALGORITHM) *** #
'''
The blue dashed line is EE that reprensent the consensus error using the distributed gradient tracking algorithm,
The orange dasched line is EE_dg that represent the consensus error using the distributed gradient algorithm.
As we can see the distributed gradient tracking algorithm is better with respect to the distributed gradient
method, the error tends to zero faster. In a distributed algorithm, the CONSENSUS ERROR is a measure of the discrepancy 
between the local estimates of the agents in the networks and the true value of the quantity being estimated.
The previous graph can provide insights into the performance and the convergence of the algorithm.
'''

###############################################################################
# generate N random colors
colors = {}
for ii in range(NN):
	colors[ii] = np.random.rand(3)

####################################################################################
''' Figure 3 : Evolution of the local estimates (DISTRIBUTED GRADIENT ALGORITHM) '''
####################################################################################
# For the distributed gradient method we need to use diminishing stepsize for convergence
# If we use a sufficiently small step-size we equally converge near to the optimal value.
if True:
	plt.figure(figsize=(8,6))
	plt.plot(np.arange(MAXITERS), np.tile(u_opt,(MAXITERS,1)), '--', linewidth=3)
	for ii in range(NN):
		plt.plot(np.arange(MAXITERS), uu_dg[ii], color=colors[ii])

	plt.xlabel(r"iterations $k$")
	plt.ylabel(r"$u_{i}^k$")
	plt.title("Evolution of the local estimates Distributed Gradient algorithm")
	plt.grid()
	
	# Generate legend for x_opt and dynamic legend for agents
	legend_labels = ['u_opt_{}'.format(i + 1) for i in range(len(u_opt))]
	legend_labels += ['agent {}'.format(i) for i in range(NN)] # in this way the labels change with the number of agents

	plt.legend(legend_labels)

	filename = 'Fig.3 Evolution of the local estimates DG.png'
	filepath = os.path.join(folder_path, filename)
	plt.savefig(filepath,bbox_inches='tight', pad_inches=0.1)

# *** COMMENT FIGURE_3 (LOCAL ESTIMATES WITH DISTRIBUTED GRADIENT ALGORITHM) *** #
'''
The two dashed line are the optimal solutions u_opt_1 and u_opt_2, the continuous lines are the local estimates that have to reach the
optimal solutions consensually. For the distributed gradient algorithm we use a diminishing stepsize that allows the local estimates 
to reach the optimal solution and to reach the consensus. 
The optimal solution is reached with more iterations with respect the GT algorithm.
'''

#################################################################################
''' Figure 4 : Evolution of the local estimates (GRADIENT TRACKING ALGORITHM) '''
#################################################################################

if True:
	plt.figure(figsize=(8,6))
	plt.plot(np.arange(MAXITERS), np.tile(u_opt,(MAXITERS,1)), '--', linewidth=3)
	for ii in range(NN):
		plt.plot(np.arange(MAXITERS), uu[ii], color=colors[ii])
	
	plt.xlabel(r"iterations $k$")
	plt.ylabel(r"$u_{i}^k$")
	plt.title("Evolution of the local estimates Gradient Tracking algorithm")
	plt.grid()
	
	# Generate legend for x_opt and dynamic legend for agents
	legend_labels = ['u_opt_{}'.format(i + 1) for i in range(len(u_opt))]
	legend_labels += ['agent {}'.format(i) for i in range(NN)]

	plt.legend(legend_labels)

	filename = 'Fig.4 Evolution of the local estimates GT.png'
	filepath = os.path.join(folder_path, filename)
	plt.savefig(filepath,bbox_inches='tight', pad_inches=0.1)

# *** COMMENT FIGURE_4 (LOCAL ESTIMATES WITH GRADIENT TRACKING ALFORITHM) *** #
'''
The two dashed line are the optimal solutions u_opt_1 and u_opt_2, the continuous lines are the local estimates that have to reach the
optimal solutions consensually. With the gradient tracking we will obtain linear convergence rate, so agents reach the optimal solutions and 
consensus faster with respect to the ditributed gradient method.
'''


################################################################################
''' Figure 5 : Cost Evolution '''
################################################################################
if True:
 plt.figure(figsize=(8,6))

 plt.plot(np.arange(MAXITERS), np.repeat(Jopt,MAXITERS), '--',label='fopt', linewidth=3)
 plt.plot(np.arange(MAXITERS), JJ,color='green',label='JJ_GT')
 plt.plot(np.arange(MAXITERS),JJ_dg,color='red',label='JJ_DG')
 plt.xlabel(r"iterations $k$")
 plt.ylabel(r"$\sum_{i=1}^N J_i(u_i^k)$")
 plt.title("Evolution of the Cost")
 plt.grid()
 plt.legend()

 filename = 'Fig.5 Evolution of the Cost.png'
 filepath = os.path.join(folder_path, filename)
 plt.savefig(filepath,bbox_inches='tight', pad_inches=0.1)

# *** COMMENT FIGURE_5 (COST EVOLUTION) *** #
'''
In this plot we can see the evolution of the cost function both for distributed gradient method and
distributed gradient tracking method. In particular, we can see how the Gradient Tracking cost function 
decrease as the gradient’s estimates approach to zero.
'''

################################################################################
''' Figure 6 : Cost Error Evolution '''
################################################################################
if True:
	plt.figure(figsize=(8,6))

	plt.semilogy(np.arange(MAXITERS), np.abs(JJ-np.repeat(Jopt,MAXITERS)), '--',label='gradient tracking', linewidth=3) # blu
	plt.semilogy(np.arange(MAXITERS), np.abs(JJ_dg-np.repeat(Jopt,MAXITERS)), '--', label='distributed gradient', linewidth=3) # arancione distribute gradient
	plt.xlabel(r"iterations $k$")
	plt.ylabel(r"$|\sum_{i=1}^N J_i(u_{i}^k)$ - $J^\star|$")
	plt.title("Evolution of the Cost Error")
	plt.legend()
	plt.grid()

	filename = 'Fig.6 Evolution of the Cost Error.png'
	filepath = os.path.join(folder_path, filename)
	plt.savefig(filepath,bbox_inches='tight', pad_inches=0.1)

# COMMENT PLOT COST ERROR: The blue line is the gradient tracking, the U rovesciata is due to a transient behaviour, but the trend is a line (linear rate),
# the red line goes to another value that is not 0 (distributed gradient method which is not working if we use a constant stepsize )

# *** COMMENT FIGURE_6 (COST ERROR) *** #
'''
The orange line represents the distributed gradient method: as we can see this method is not working well with respect to the gradient tracking method,
we reach the optimal solution after a huge number of iterations.
The blue line instead represents the distributed gradient tracking: in this case we can notice the linear rate with some  waves related transient 
behaviour, the blue line goes rapidly to the optimal solution, so to an error value which is almost zero.
'''
################################################################################
''' Figure 7 : Mean value of the norm of the innovation term '''
################################################################################
# mean (|∇J_{i}(u_{i}^{k+1}) - ∇J_{i}(u_{i}^{k})|)
if True:
	plt.figure(figsize=(8,6))

	plt.semilogy(np.arange(MAXITERS),np.mean(np.linalg.norm(innovation, axis=-1),axis=0), label='mean (Innovation_norm)',linewidth=2)
	#plt.semilogy(np.arange(MAXITERS),np.mean(np.linalg.norm(YY, axis=-1),axis=0))
	
	if False:
	# To show the innovation norm of each agent
		for ii in range (NN):
			plt.semilogy(np.arange(MAXITERS), np.linalg.norm(innovation[ii],axis=-1),'--',label=f"agent_{ii}",)
			#plt.semilogy(np.arange(MAXITERS),np.linalg.norm(YY[ii], axis=-1),'--',label=f"agent_{ii}",)
	
	plt.legend()
	plt.xlabel(r"iterations $k$")
	plt.ylabel(r"$|\nabla J_{i}(u_{i}^{k+1}) - \nabla J_{i}(u_{i}^{k})|$")
	plt.title("Evolution of the mean value of the norm of innovation term") # (Norm of the gradient) 
	plt.grid()
	

	filename = 'Fig.7 Mean of the Norm of the innovation term.png'
	filepath = os.path.join(folder_path, filename)
	plt.savefig(filepath,bbox_inches='tight', pad_inches=0.1)

# *** COMMENT FIGURE_7 (MEAN VALUE OF THE NORM OF THE GRADIENT) *** #
'''
The INNOVATION term in the Distributed Gradient Tracking algorithm represents the difference between the local gradient estimate and the global
gradient estimate. The innovation term is used to update the local gradient estimate and improve the accuracy of the algorithm. The NORM of the
innovation term is a useful metric because it providesis a measure of the discrepancy between the local and global gradient estimates, and can 
be used to monitor the convergence of the algorithm. In general, a smaller norm of the innovation term indicates better convergence and accuracy
of the algorithm. 
'''

plt.show()

