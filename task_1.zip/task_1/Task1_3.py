"""
=========================================================================================================
                                    DISTRIBUTED AUTONOMOUS SYSTEM
=========================================================================================================
Group 11
Santoro Luca, 0001005415
Spennato Armando, 0001006172

Professor: Giuseppe Notarstefano   Tutor: Ivano Notarnicola  Tutor: Lorenzo Picherri
=========================================================================================================
                        TASK 1: Distributed Classification via Neural Networks
=========================================================================================================
"""

# we need to import the following Python Standard Libraries that contain the syntax, semantics, and tokens of
# Python which we need to accomplish the task.

from Functions import *
from Plt_Functions import*

import matplotlib.pyplot as plt
import numpy as np
from keras.datasets import mnist # To import our Dataset

from imblearn.under_sampling import RandomUnderSampler # for Balancing
from sklearn.model_selection import train_test_split   # For Shuffling


from collections import Counter
from copy import deepcopy

from termcolor import colored # to change the characteristics of the terminal cost
from tabulate import tabulate # per stampare i dati a terminale in forma tabulare (maniera più elegante per presentare i dati )

from sklearn.metrics import precision_score, accuracy_score       # To find the precision and accuracy of our NN
from imblearn.metrics import sensitivity_score, specificity_score # To find the sensitivity and specificity of our NN



import random
random.seed(42)
np.random.seed(42)

##########################################################################

print(colored('\n-------------------------------------------------------------------------------------\n','red',attrs=['bold']))
print(colored('\n*** TASK 1: CLASSIFICATION VIA NEURAL NETWORK ***\n','red',attrs=['bold']))
print(colored('\n*** TASK 1.3: DISTRIBUTED TRAINING ***\n','red',attrs=['bold']))

''' ----> *** Simulation saving *** <----'''

specified_subfolder = "Task 1.3"
folder_path = SaveSimulation(specified_subfolder, None)

# In distributed training, the goal is to parallelize the training process 
# by dividing the data and computations among multiple nodes (Agents).

####################################################################################
'''Section 1: SIMULATION FLAGS AND PARAMETERS'''
###################################################################################

'''%%%% SIMULATION FLAGS %%%%'''

select_digit = 4 # To be able to select a digit (from 0 to 9)

confusion_matrix_flag = True
wrong_classified_digits = True

'''%%%% PARAMETERS GRAPH %%%% '''
NN = 10 #number of agents
graph_type ="Cycle" # in order to change the graph type: "Binomial", "Path", "Star", "Cycle", "Complete" 

'''%%%% LABELED DATA SETTING %%%%'''
AGENT_train_data = 512 # Train data for each agent
SIZE_TRAIN = AGENT_train_data * NN # total number of train data

# Test data do not need to be separated among the agents as the final 
# model reach consensus and the test data are used only to evaluate 
# the performance of the network

'''%%%% PARAMETERS NEURAL METWORK %%%%'''

d = [784,8,1] # Number of neurons in each layer.

# Note: with d_c we indicate the number of neuron of the current layer
#            d_n we indicate the number of neurons in the next layer

T = len(d) # Number of Layers of our neural network

MAX_EPOCHS = 200 # Ephochs
batch_size = 128 # batch size is the amount of training data used in a single iteration of updating the network weights. 
N_batches=int(AGENT_train_data/batch_size) # number of necessary batch for each agent  (we devide the number of train data in groups of 32 elements)
step_size = 5e-3 #Learning rate (Gradient Method) 

####################################################################################
'''section 2: IMPORT AND PRE-PROCESSING OF DATASET'''
####################################################################################
# LOADING the Mnist Dataset
(X_train, y_train), (X_test, y_test) = mnist.load_data()


# We show the DIMENSIONS of the data obtained from MNIST
print(colored('\n*** INITIAL DATA DIMENSIONS ***\n','green',attrs=['bold']))
print('X_train: ' + str(X_train.shape))
print('y_train: ' + str(y_train.shape))
print('X_test:  ' + str(X_test.shape))
print('y_test:  ' + str(y_test.shape))
# We can see that there are 60k images in the training set and 10k images in the testing set.
# The dimension of our training vector is (60000, 28, 28),
# this is because there are 60k grayscale images with the dimension 28X28



# We reshape the initial matrix data [28x28] in a vector of dimension [784×1] in order to provide the correct
# dimension of the inputs of our neural network.
# MNIST is a three-dimensional data, we'll reshape it into the two-dimensional one.
X_train = X_train.reshape(60000, 784)
X_test = X_test.reshape(10000, 784)

# We show the NEW DIMENSIONS of the RESHAPED data
print(colored('\n*** RESHAPED DATA DIMENSIONS ***\n','green',attrs=['bold']))
print('X_train: ' + str(X_train.shape))
print('X_test: ' + str(X_test.shape))


# NORMALIZATION
# The data in the training set and test set have a discrete value between 0 and 255,
# that represent the gray scale pixel values. Normalizing these pixel values between
# 0 and 1 helps in speeding up the training. Since we are going to use stochastic gradient
# descent, normalizing data will also help in reducing the chance of getting stuck in local optima.
# To normalize the data, we represent it as float type and divide it by 255 as shown
# in the following code:

# We change the dType as float
X_train = X_train.astype('float32')
X_test = X_test.astype('float32')

# We devide each data that has a value in the range [0,255] by 255
X_train /= 255
X_test /= 255


###################################
''' DATA BALANCING'''
###################################

# Since we need to assign labels 0 and 1, we need to change the dtype of the data
# contained in the arrays y_train and y_set, labels array
y_train = y_train.astype('int32')
y_test = y_test.astype('int32')

# Associate 0 to data which NOT represent the number we want to classify

for i in range(0, len(y_train)):
    if y_train[i] == select_digit:
        y_train[i] = 1
    else:
        y_train[i] = 0

for i in range(0, len(y_test)):
    if y_test[i] == select_digit:
        y_test[i] = 1
    else:
        y_test[i] = 0

print(colored('\n*** LABELS CHANGED ***\n','green',attrs=['bold']))
print(f'The labels are:\t{np.unique(y_test)}')


# BALANCING:
# Due to the previous manipulation our training set is not balanced (we can also see it from the t-SNE plot), because
# the class related to the label 0 is a MAJORITY CLASS while the one related to the label 1 is a MINORITY CLASS.

# There are different tecniques to obtain balanced dataset. We exploit the UNDERSAMPLING technique, which remove examples
# from the training dataset that belong to the Majority class in order to better balance the class distribution.
# In this way we are able to obtain a better training of the machine learning model.

RandomUS = RandomUnderSampler()
X_train_blc, y_train_blc = RandomUS.fit_resample(X_train, y_train)
X_test_blc, y_test_blc = RandomUS.fit_resample(X_test, y_test)

print(colored('\n*** DATA BALANCED ***\n','green',attrs=['bold']))

print(np.shape(X_train_blc))
print(np.shape(y_train_blc))

# Shuffling the train and the test set

X_train_blc,_,y_train_blc,_= train_test_split(X_train_blc, y_train_blc)
X_test_blc,_,y_test_blc,_= train_test_split(X_test_blc, y_test_blc)


if True:
    print('Resampled dataset shape %s' %Counter(y_train_blc))
    print(np.shape(X_train_blc))
    print(np.shape(y_train_blc))


print(colored('\n*** ALL DATA AND LABELS ARE READY TO BE ELABORATED ***\n','blue',attrs=['bold']))

'''=================================================================================================================================================='''

###########################################################################
''' GRAPH G GENERATION '''
###########################################################################
# If we want to define a network system with a given number of agents that communicate
# according to some topology we need to define a graph. Then we get the adjacency matrix AA associated to that graph.
# We need AA because is the matrix used in the consensus.
print(colored('\n*** Graph G generation ***\n','cyan',attrs=['bold']))

####################
# GRAPH DEFINITION #
####################
GG = graph_generation(NN,graph_type,True)
filename = f'Fig.1 {graph_type}_graph.png'
filepath = os.path.join(folder_path, filename)
plt.savefig(filepath)
plt.show()

#####################
# Adjacency  matrix #
#####################
ADJ = Adj_matrix(GG,NN,True)

##############
'''WEIGHTS'''
##############
print(colored('\n*** WEIGHTS ***\n','green',attrs=['bold']))
# weighthed matrix
ww = weighted_matrix(ADJ,NN,True)


#########################################
''' SPLITTING THE DATASET AMONG AGENT '''
#########################################

print(colored('\n*** SPLITTING THE DATASET AMONG AGENT ***\n','blue',attrs=['bold']))
X_train_agent,y_train_agent = split_data_agents (NN,X_train_blc,y_train_blc,AGENT_train_data,True)


######################
''' INITIALIZATION'''
######################
print(colored('\n*** DISTRIBUTED TRAINING ***\n','red',attrs=['bold']))
print(colored('\n*** Initialization ***\n','red',attrs=['bold']))
# Network Variables (distributed framework)

# INITIAL WEIGHTS (in machine learning scenario)/ initial input trajectory (in optimal control scenario)
uu_init = []
for l_idx in range(T-1):
    uu_init.append(np.random.randn(d[l_idx+1], d[l_idx]+1)/10)
    #uu_init.append(np.random.randn(d[l_idx+1], d[l_idx]+1) * np.sqrt(1/(d[l_idx]+d[l_idx+1]))) #Xavier/Glorot initialization:
    #uu_init.append(np.random.randn(d[l_idx+1], d[l_idx]+1) * np.sqrt(1/(d[l_idx]))) # He initialization
    #uu_init.append(np.random.uniform(low=-0.1, high=0.1,size=(d[l_idx+1], d[l_idx]+1))) # Uniform initialization


# we create a list uu and uu_kp1, the list uu contains NN independent copies of uu_init,
# while uu_kp1 is an independent copy of uu. Changes to uu will not affect uu_kp1, and vice versa.
uu = [deepcopy(uu_init) for agent in range(NN)] # NN copies
uu_kp1 = deepcopy(uu)

# INITIAL GRADIENT DIRECTION 
ss_init = []
for l_idx in range(T-1):
    ss_init.append(np.zeros((d[l_idx+1], d[l_idx]+1))) # same dimentiion of uu_init
# Also in this case we create two more lists that contain nn independent copies of ss_init
ss = [deepcopy(ss_init) for agent in range(NN)] # same dimention of uu
ss_kp1 = deepcopy(ss)

# INITIAL GRADIENTS
grads_init = []
for l_idx in range(T-1):
    grads_init.append(np.zeros((d[l_idx+1], d[l_idx]+1))) # same dimention of uu_init
# We create a list that contains NN indipendent copies of grads_init
grads = [deepcopy(grads_init) for agent in range(NN)] # same dimention of uu

# In particular for each agent we have uu, uu_kp1, ss, ss_kp1, grads

# INITIALIZATION of the cost function, its Gradient and the consensus error
# plot variables 
u_err = np.zeros((MAX_EPOCHS, NN))
JJ = np.zeros((MAX_EPOCHS, NN)) # Cost function
NormGradJ = np.zeros((MAX_EPOCHS, NN))
consensus_erros = np.zeros((MAX_EPOCHS, NN))
true_pred = np.zeros((MAX_EPOCHS, NN))

# Initialization of Gradient Tracking Algorithm
# As we know from theory as we know from theory in the gradient tracking algorithm case,
# the initializations (u^{0}_{i} and ss^{0}_{i} = ∇ JJ_{i}(u^{0}_{i})) are necessary for convergence.

# We compute the gradients of each agent by considering a batch of images in order to 
# initialize the tracking variable ss of each agent.
# for each agent
for agent in range(NN):
    # for each image in the batch
    for img in range(batch_size):
        xx = FORWARD_pass(uu[agent], X_train_agent[agent, img],T) # in order to obtain the prediction,
        loss, loss_grad = BCE(xx[-1][0], y_train_agent[agent, img]) # xx[-1][0] is xT agent i, output NN.
          # loss_grad -->  terminal coefficient of the costate
        _, grad_kp1 = BACKWARD_pass(xx, uu[agent], loss_grad,T)
          # grad_kp1 -->  delta_u (gradiente of J wrt u), gradient of the loss function, ha un numero di elementi pari a T-1, e ogni elemento ha una forma uguale a un elemento di uu
        
        # for each agent we update the gradient of each layer by aggregating the gradients calculated for each image in the batch for that layer
        for l_idx in range(T-1): 
            grads[agent][l_idx] += grad_kp1[l_idx]
    # for each layer, we assign the aggregated gradients of each agent to a specific tracking variable for that layer 
    for l_idx in range(T-1): 
        ss[agent][l_idx] = grads[agent][l_idx]

print('Initialization Terminated')
################
''' TRAINING '''
################
print(colored('\n*** Start Training ***\n','red',attrs=['bold']))

# The following piece of code is related to the training of the neural network 
# using the gradient tracking algorithm, in a distributed or 
# decentralized setting. 
# The code involves updating weights and gradients for each agent in 
# a network based on its neighbors information.

for epoch in range(MAX_EPOCHS):
    for batch_iter in range(N_batches):
        for agent in range(NN):
            neighs = np.nonzero(ADJ[agent])[0] # we find the neighbors

            ####################################################
            """ Gradient Tracking Algorithm - Weights Update """
            ####################################################
            for l_idx in range(T-1):
                # For each agent we update the weights of each layer
                uu_kp1[agent][l_idx] = (ww[agent, agent] * uu[agent][l_idx]) - (step_size * ss[agent][l_idx])
                # We add the contributiions of the neighbours into the current agent's weights updates
                for neigh in neighs:
                    uu_kp1[agent][l_idx] += ww[agent, neigh] * uu[neigh][l_idx]

            batch_grads_kp1 = [np.zeros_like(u_l) for u_l in uu[agent]] # to store the gradients of each layer for each image in the batch

            for batch_el in range(batch_size): 
                img = batch_iter * batch_size + batch_el # we need this index to select the image inside the single batch (0...31,32...63 ecc)

                # Forward pass (to find all signals)
                xx = FORWARD_pass(uu_kp1[agent], X_train_agent[agent, img], T)

                # Loss evaluation
                loss, loss_grad = BCE(xx[-1][0], y_train_agent[agent, img])

                JJ[epoch, agent] += loss 
                # For each epoch, we update the loss values of each agent (for plot) 

                # Backward pass (to compute the gradients of each layer of each image inside the batch)
                _, grad_kp1 = BACKWARD_pass(xx, uu_kp1[agent], loss_grad, T)

                # we aggregate the gradients for each layer considering all the images inside the batch 
                for l_idx in range(T-1):
                    batch_grads_kp1[l_idx] += grad_kp1[l_idx] / batch_size
                    # We normalize the gradient on the batch dimension for a better updates' consistency.

                    NormGradJ[epoch, agent] += np.linalg.norm(grad_kp1[l_idx])
                    # For each epoch, we aggregate the norm of the gradient loss values for each layer
                    # considering each image inside the batch, for each agent (for plot)

                # For accuracy plot
                # compute the prediction for the current img
                prediction = round(FORWARD_pass(uu_kp1[agent], X_train_agent[agent, img],T)[-1][0])
                # we keep track, for each epoch and for each agent, of the correct prediction for each image inside the batch 
                true_pred[epoch, agent] += int(prediction == y_train_agent[agent, img]) # add 1 if True 
            
            ###############################################
            """ Gradient Tracking Algorithm - SS Update """
            ###############################################
            for l_idx in range(T-1):
                # for each agent we update the tracking variable of each layer
                ss_kp1[agent][l_idx] = (ww[agent, agent] * ss[agent][l_idx]) + (batch_grads_kp1[l_idx] - grads[agent][l_idx])
                # We add the contributiions of the neighbours into the current agent's ss updates
                for neigh in neighs:
                    ss_kp1[agent][l_idx] += ww[agent, neigh] * ss[neigh][l_idx]

                # in the ss update we consider the difference between the last batch gradient and the it's previous version  
                # So, in the following way we store the current batch gradient, that will be use in the next update of ss.
                # In this way the ss_kp1 will be always based on the most recent gradient information from each batch. 
                grads[agent][l_idx] = batch_grads_kp1[l_idx] / N_batches 
                # We normalize the batch gradient for the number of batches to ensure a uniform contribution of each batch.

    # Update (synchronous) for each epoch
    # in this way we define the starting points for the next iteration(epoch) of the algorithm  
    for agent in range(NN):
        for l_idx in range(T-1):
            uu[agent][l_idx] = uu_kp1[agent][l_idx]
            ss[agent][l_idx] = ss_kp1[agent][l_idx]

    ##########################
    """ Consensus part """
    ##########################
    uu_mean = [np.zeros_like(u_l) for u_l in uu[0]]

    # For each layer we compute the average of the weights of each agent 
    # (need for find the consensus error)

    for l_idx in range(T-1):
        for agent in range(NN):
            uu_mean[l_idx] += uu[agent][l_idx] / NN   # consensus value 

    # we compute the consensus error as the distance of the agent weights from the consensus value (weight's average)
    # For plot
    for agent in range(NN):
        for l_idx in range(T-1):
            consensus_erros[epoch, agent] += np.abs(uu[agent][l_idx] - uu_mean[l_idx]).sum() / uu_mean[l_idx].size
            

    # useful prints along the epoch
    if epoch % 1 == 0:
        mean_accuracy = np.mean(true_pred[epoch] / (batch_size * N_batches)) # mean accuracy over all the agent's data
        print(f'Epoch {epoch+1:d} | Loss: {np.mean(JJ[epoch]):.4f} | Gradient Loss: {np.mean(NormGradJ[epoch]):.4f} | Average Accuracy: {mean_accuracy:.4f}')

print()
print("Training complete!")
print()
###################
'''Accuracy plot'''
###################
# Accuracy during the training of each agent
# The accuracy plot, allows to evaluate several aspects to understand how your model is performing during training.
# The accuracy plot can show any model convergence issues on different parts of the distributed system.
plt.figure()
plt.title('Accuracy evolution during network training')
for agent in range(NN):
    plt.plot(range(MAX_EPOCHS), true_pred[:, agent] / (batch_size * N_batches), label=f'Agent {agent}')
plt.xlabel('Epochs')
plt.ylabel('Accuracy')
plt.grid()
plt.legend()
filename = 'Fig.2 Accuracy evolution during network training.png'
filepath = os.path.join(folder_path, filename)
plt.savefig(filepath,bbox_inches='tight', pad_inches=0.1)
plt.show()



#############
'''TESTING'''
#############
print(colored('\n*** TESTING ***\n','green',attrs=['bold']))

print("Evaluation of the network:\n")
# Computes the mean error over uu
'''
we compute the consensus error as the distance of the agent weights from the consensus value (weight's average)
At the end of the training, finding the final error of each agent
'''
#print("\nAgent erros:")
uu_mean = [np.zeros_like(u_l) for u_l in uu[0]]
for l_idx in range(T-1):
    for agent in range(NN):
        uu_mean[l_idx] += uu[agent][l_idx] / NN # consensus value

u_err = np.zeros(NN) # for print 
for agent in range(NN):
    for l_idx in range(T-1):
        u_err[agent] += np.linalg.norm(uu_mean[l_idx] - uu[agent][l_idx])
    #print(f' - Agent {agent} mean_error = {u_err[agent]}')

########
# Table
########
print(colored('\nAgent erros\n','blue',attrs=['bold']))
# Printing the results in tabular form
table_meanError = [["Agent", "Error"]]
for agent in range(NN):
        row = [agent, u_err[agent]]
        table_meanError.append(row)
print(tabulate(table_meanError, headers="firstrow", tablefmt='fancy_grid')) 



####################################################################################################
# To evaluate the performance of our model we compare the accuracy on each agent's training data to 
# the accuracy on the total test data.

# High accuracy on training data: This may indicate that the model has learned well from the training data,
# but is not a sure indicator of generalization ability because  a model may fit too much to training data 
# (overfitting) and therefore perform poorly on new data.

# High accuracy on test data: Indicates that the model is able to generalize well on new data, which it
# did not see during training. This is the desired result because the main goal of a model is to make accurate
# predictions on new data.

print(colored('\nAgent Accuracies\n','blue',attrs=['bold']))
# ON THE TRAIN DATA
Accuracy_train = np.zeros(NN)
for agent in range (NN):
    correct_pred = 0
    for img in range(AGENT_train_data):
        pred = round(FORWARD_pass(uu[agent], X_train_agent[agent, img],T)[-1] [0])
        if pred == y_train_agent[agent, img]:
            correct_pred +=1
        
        Accuracy_train[agent]=correct_pred/AGENT_train_data*100

# ON THE TEST DATA 
Accuracy_test = np.zeros(NN)
for agent in range(NN):
    correct_pred = 0
    for img in range(len(X_test_blc)):
        pred = round(FORWARD_pass(uu[agent], X_test_blc[img],T)[-1][0])
        if pred == y_test_blc[img]:
                correct_pred +=1
        
        Accuracy_test[agent]=correct_pred/len(X_test_blc)*100

# We print the table
table_accuracy = [["Agent", "Accuracy on train set per Agent","Accuracy on test set" ]]
for agent in range(NN):
        # We use f-strings to format the accuracy values with two decimal places.
        acc_train_percent = f"{Accuracy_train[agent] :.2f} %"
        acc_test_percent = f"{Accuracy_test[agent] :.2f} %"

        row = [agent, acc_train_percent, acc_test_percent]
        table_accuracy.append(row)
print(tabulate(table_accuracy, headers="firstrow", tablefmt='fancy_grid'))

#################################################################################################################


print(colored('\n-------------------------------------------------------------------------------------\n','red',attrs=['bold']))

#############
''' PLOTS '''
#############
# Visualizing the convergence of a distributed training process is critical to understanding 
# the performance and effectiveness of the distributed model.
# To evaluate convergence we use different plots:


#############################
'''Loss function evolution'''
#############################
# 1) Network loss across epochs (during training). A decrease in losses is a positive sign 
# of convergence. If the loss is decreasing, it indicates that our model is converging.

# Loss functions ( or Error functions) are used to gauge the error between the prediction output 
# and the provided target value. A loss function will determine the model’s performance by comparing 
# the distance between the prediction output and the target values.
# Smaller loss means the model performs better in yielding predictions closer to the target values.

plt.figure('Loss function')
plt.title('Evolution of the loss function')
plt.semilogy(range(MAX_EPOCHS),np.sum(JJ, axis=1), label='Total loss Evolution', linewidth = 3,color='red')
#for agent in range(NN):
#     plt.semilogy(range(MAX_EPOCHS), JJ[:, agent], linestyle = ':',label=f"agent{agent}")
plt.xlabel(r'Epochs')
plt.ylabel(r'$\sum_{n=1}^N J$')
plt.grid()
plt.legend()
filename = 'Fig.3 Evolution of the loss function.png'
filepath = os.path.join(folder_path, filename)
plt.savefig(filepath,bbox_inches='tight', pad_inches=0.1)
plt.show()
######################################
''' Norm of the Gradient function  '''
######################################
# 2) Norm of the gradient. Plotting the norm of the gradient during distributed training can provide insights 
# into how gradients are changing over time and across different nodes (Agents). 
# We can evaluate the stability of the model's convergence. Gradients that are consistent
# and not too large or too small can indicate that the model is learning stably.

# By analyzing the gradient norm, we can optimize the learning rate. 
# If the gradient norm is very large, it may be necessary to reduce the learning rate
# to avoid instability problems. Conversely, if it is very small, you may need 
# to increase the learning rate to accelerate convergence.


# A gradient approaching zero may indicate that the model has reached a region of local minimum.

plt.figure('Norm of Gradient function')
plt.title('Evolution of the norm of the gradient of the cost function')
plt.semilogy(range(MAX_EPOCHS), np.sum(NormGradJ, axis=-1), label='Total Norm Gradient Evolution', linewidth = 2,color='green')
#for agent in range(NN):
#    plt.semilogy(range(MAX_EPOCHS), NormGradJ[:, agent], linestyle = ':',label=f"agent{agent}")
plt.xlabel(r'Epochs')
plt.ylabel(r"$|| \nabla J_w(x_t^k) ||_2$")
plt.grid()
plt.legend()
filename = 'Fig.4 Evolution of the norm of the gradient of the cost function.png'
filepath = os.path.join(folder_path, filename)
plt.savefig(filepath,bbox_inches='tight', pad_inches=0.1)
plt.show()
##########################################
'''Evolution of the error'''
###########################################
# 3) Evolution of the Consensus Error. Consensus error is a key concept in distributed training and
# refers to the discrepancy between models trained on different nodes or devices. 
# This error can affect the convergence of the model and its ability to generalize.  
# Minimizing this error is critical to ensuring a high-quality and well-generalized final model.


''' Model consistency:'''
# In a distributed training system, the goal is to have a coherent and consistent 
# model across all nodes. Consensus error measures how much the models at different 
# nodes deviate from each other. Minimizing this error is essential to ensure model consistency.

''' Efficient Convergence:'''
# A high consensus error may indicate that models at different nodes are not converging effectively.
# This could be due to issues in synchronizing model weights between nodes or differences 
# in data distribution.

'''Prevention of discrepancies:'''
# A high consensus error could be a sign of possible divergences between models at different nodes.
# Divergence can lead to inconsistent results and compromise the overall quality of the model.

'''Generalization of the model:'''
# A model with low consensus error is more likely to generalize well to new data. 
# If the models at different nodes are too different, the model may struggle to generalize 
# effectively.

'''Effects on the quality of the final model:'''
# Consensus error can directly affect the quality of the final model.
# By reducing the consensus error, we aim to obtain a more robust and accurate model.

'''Proper synchronization:'''
# Minimizing consensus error involves adequate synchronization between nodes during training. 
# Efficient synchronization is critical to avoid divergence issues and ensure that all nodes 
# contribute cohesively to the model.

'''Resource optimization:'''
# Reducing consensus error can help optimize resource utilization by ensuring 
# that each node contributes meaningfully to the training process without introducing 
# significant discrepancies.

plt.figure('Evolution of the error', figsize=(15,7))
# First subplot
plt.subplot(1, 2, 1)
plt.title('Evolution of agent weights error from the mean value')
for agent in range(NN):
    plt.semilogy(range(MAX_EPOCHS), consensus_erros[:, agent], label=f"agent{agent}")
plt.xlabel('Epochs')
plt.ylabel(r'$|| u_i - u^\star||_2, \quad u^\star = \frac{1}{N} \sum_{i=1}^N u_i \quad \forall i=1,\dots,N $')
plt.grid()
plt.legend(loc="upper right")

# In the first subplot we use the logarithmic scale for better visualization of small values

# Second subplot
plt.subplot(1, 2, 2)

plt.plot(consensus_erros.mean(axis=1),linewidth = 3,label = f"Average Consensus Error")  # Media dell'errore di consenso su tutti gli agenti per ogni epoca
plt.title('Average consensus error')
plt.xlabel('Epochs')
plt.ylabel('Average consensus error')
plt.grid()
plt.legend(loc="upper right")

plt.subplots_adjust(left=0.1, bottom=0.1, right=0.9, 
                    top=0.9, wspace=0.2,hspace=0.4)
plt.suptitle('Evolution of the consensus error')
filename = 'Fig.5 Evolution of the consensus error.png'
filepath = os.path.join(folder_path, filename)
plt.savefig(filepath,bbox_inches='tight', pad_inches=0.1)

plt.show()

#################################################################################
# TEST
# After training, the model is evaluated using additional metrics.
# The metrics to be computed strongly depend on the nature of the model output.
# So since we are deal with a classification (or a discrete variable) 
# he Confusion matrix, Precision, Accuracy, Sensitivity and Specificity can
# be used.


prediction = [] # to store the prediction for each agent (outputs NN)
for agent in range(NN):
  prediction.append([])
  for img in range(len(X_test_blc)):
    prediction[agent].append(round(FORWARD_pass(uu[agent], X_test_blc[img],T)[-1][0])) 




missclass_indexes = [] # in order to store the indexes where we have a wrong prediction, for each agent
for agent in range(NN):
  missclass_indexes.append([])
  for indice, (element1, element2) in enumerate(zip(y_test_blc, prediction[agent])):  #zip unisco (,) # enumerate "conto le coppie"
    if element1 != element2:
        missclass_indexes[agent].append(indice)

goodclass_indexes = [] # in order to store the indexes where we have a true prediction, for each agent
for agent in range(NN):
  goodclass_indexes.append([])
  for indice, (element1, element2) in enumerate(zip(y_test_blc, prediction[agent])):  
    if element1 == element2:
        goodclass_indexes[agent].append(indice)



######################
'''Confusion matrix'''
######################

# A Confusion matrix in general is an N × N matrix used for evaluating the performance of a classification model, where N is the
# number of target classes. Since we deal with a binary classifier N = 2. The matrix compares the actual target values with those predicted by
# the machine learning model. The confusion matrix provides a detailed insight of how the model performs and which kind of error it makes.
# It is a tabular summary of the number of correct and incorrect predictions made by a classifier.
# Confusion matrices are widely used because they give a better idea of a model’s performance than
# classification accuracy does. For example,in classification accuracy, there is no information about
# the number of misclassified instances.

print(colored('\n*** CONFUSION MATRICES ***\n','green',attrs=['bold']))
if confusion_matrix_flag == True:
  for agent in range(NN):
    print(colored("\n Confusion matrix agent {}\n".format(agent), 'green', attrs=['bold']))
    confusion_matrix_plot (y_test_blc,prediction[agent])
    filename = f'Confusion Matrix agent {agent}.png'
    filepath = os.path.join(folder_path, filename)
    plt.savefig(filepath,bbox_inches='tight', pad_inches=0.1)

    plt.show()
################################
'''Plot missclassified digits'''
################################

# It is always good to display your model output. In case of classification, the misclassified samples 
# are often displayed to gain insight into the types of mistakes that the model is making. So let’s display 
# 10 of the misclassified images using Matplotlib library:

if wrong_classified_digits == True:
  agent = 0
  print("\n (10) Wrong classified digits agent ",agent)
  wrong_classified_digits_plot(X_test_blc,y_test_blc,missclass_indexes[agent],prediction[agent])
  filename = f'(10) Wrong classified digits agent {agent}.png'
  filepath = os.path.join(folder_path, filename)
  plt.savefig(filepath,bbox_inches='tight', pad_inches=0.1)
  plt.show()

print(colored('\n-------------------------------------------------------------------------------------\n','red',attrs=['bold']))

##############
'''Metrics'''
##############

print(colored('\n*** METRICS ***\n','green',attrs=['bold']))
''' Accuracy ''' # Measures how often the classifier makes the correct prediction.
''' Misclassification rate ''' # Is a metric that tell us the percentage ofobservations
# that were incorrectly predicted by a classification model
''' Precision ''' # It tells us how many predictions are actually positive out of all the total positive predicted
''' Sensitivity ''' # The percentage of positive outcomes the model is able to detect
''' Specificity ''' # The percentage of negative outcomes the model is able to detect


for agent in range(NN):

   pred_array = np.array(prediction[agent]) 
   Accuracy = accuracy_score(y_test_blc, pred_array) # posso calcolare l accuratezza direttamente cosi senza dover applicare la formula
   precision = precision_score(y_test_blc, pred_array)
   sensitivity = sensitivity_score(y_test_blc, pred_array)
   specificity = specificity_score (y_test_blc, pred_array)

   #print ('Metrics Table agent',agent)
   print(colored("\n Metrics Table agent {}\n".format(agent), 'green', attrs=['bold']))
   # We create a table that contains all the metrics
   table_metrics = [["Accuracy",round(Accuracy*100,2)],
            ["Misclassification Rate",round((len(missclass_indexes[agent])/len(prediction[agent]))*100,2)],
            ["Precision",round(precision*100,2)],["Sensitivity",round(sensitivity*100,2)],
            ["Specificity",round(specificity*100,2)]]

   print(tabulate(table_metrics,headers=["Metric","Value(%)"],tablefmt="pretty"))

   print (f'\nNumber of Goodclass: {len(goodclass_indexes[agent])}   Number of Missclass: {len(missclass_indexes[agent])}\n')#

###################################
'''Simulation parameters file'''
###################################

# We save a file with all simulation parameters
filepath = os.path.join(folder_path)
f = open(f"{filepath}/Simulation_Params.txt","a")
f.write(f"d = {d}\n")
f.write(f"NN = {NN}\n")
f.write(f"MAX_EPOCHS = {MAX_EPOCHS}\n")
f.write(f"batch_size = {batch_size}\n")
f.write(f"AGENT_train_data  = {AGENT_train_data}\n")
f.write(f"step_size = {step_size}\n")
f.write(f"Accuracy_train = {Accuracy_train[0]:.2f}\n")
f.write(f"Accuracy_test = {Accuracy_test[0]:.2f}\n")
f.close()

######################################################

###################################
'''Testing file'''
###################################
filepath = os.path.join(folder_path)
file = open(f"{filepath}/Testing.txt", "w")
file.write('\nTESTING\n\n')
####### Agent errors
file.write('\nAgent errors\n')
file.write(tabulate(table_meanError, headers="firstrow", tablefmt='fancy_grid'))
file.write("\n\n")

####### Agent Accuracies table
file.write('\nAgent Accuracies\n')
# we write table on file
file.write(tabulate(table_accuracy, headers="firstrow", tablefmt='fancy_grid'))

#########################
file.write("\n\n")

###### metrics table per agent
for agent in range(NN):
    
    file.write("\nMetrics Table agent {}\n".format(agent))
    # we write table on file
    file.write(tabulate(table_metrics, headers=["Metric", "Value(%)"], tablefmt="pretty"))
    file.write(f'\nNumber of Goodclass: {len(goodclass_indexes[agent])}   Number of Missclass: {len(missclass_indexes[agent])}\n')
file.close()