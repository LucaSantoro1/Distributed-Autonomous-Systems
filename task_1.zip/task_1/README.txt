=========================================================================================================
                         			DISTRIBUTED AUTONOMOUS SYSTEM
=========================================================================================================
Group 11
Santoro Luca, 0001005415
Spennato Armando, 0001006172

Professor: Giuseppe Notarstefano   Tutor: Ivano Notarnicola  Tutor: Lorenzo Picherri
=========================================================================================================
                        TASK 1: Distributed Classification via Neural Networks
=========================================================================================================

This README is related to the fist Task of the Assignment couse project.
------------------------------------------------------------------------
# General Description
All the files related to the Task 1 are stored inside the folder task_1. The project is organized as follow: in the folder task_1 we found 5 file .py, 3 related to the different point of the Task 1 (Task1_1.py,Task1_2.py,Task1_3.py), and 2 (Function.py and Plt_Functions.py) related to all the functions used. This was done for code readability. In particular in Plt_Functions.py there are all the functions used for plotting.
In the folder there is also the folder imgs. This folder is automatically created when the first simulation occurs. Inside images each.py ​​file has its own simulation folder. After the simulation of each file.py we store all the related plots in a proper folde inside imgs. The name of each folder will contain the time and date of the relevant simulation.

All files provide useful information about the terminal to understand the execution flow.

More inside the files:

###################################
Task 1.1 - Distributed Optimization
###################################
file Task1_1.py
-----------------------------------
# Description
This file is related to the Distributed Optimization. Gradient Tracking (GT) and Distributed Gradient (DG) algorithm are implemented in such a way as to highlight the advantages of Gradient Tracking.

In the file there is the possibility to choose between different types (Random, Path, Star, Cycle, Complete) of graph and different weights(euristic weights,Metropolis-hastings weights) and the step size type for Distributed Gradient.

# Figures
Running this file will generate 7 figures (which will be saved in the Task_1/imgs/Task 1.1 folder):
• Fig.1 Graph
• Fig.2 Evolution of the consensus error
• Fig.3 Evolution of the local estimate DG
• Fig.4 Evolution of the local estimate GT
• Fig.5 Evolution of the cost
• Fig.6 Evolution of the cost error
• Fig.7 Mean of the Norm of the innovation term


###############################
Task 1.2 - Centralized Training 
###############################
file Task1_2.py
-----------------------------------
# Description
This file is related to the Centalized Training. 
At the beginning of the file there are several flag, in order to abilitate/disabilitate plot 
All the main points and the metrics used to evaluate the NN are explained in the report.

# Figures
Running this file will generate  figures (which will be saved in the imgs/Task 1.2 folder):
• Fig.1 Image_MNIST
• Fig.2 Histogram
• Fig.3 TSNE_Original_Labels
• Fig.4 TSNE_Modified_Labels
• Fig.5 TSNE_Balanced_Dataset
• Fig.6 Confusion_Matrix
• Fig.7 Wrong_Classified_digits
• Fig.8 Cost_Function_Evolution
• Fig.9 Norm_of_the_Cost_Function_Gradient_Evolution
Furthermore, a text file will be generated inside the simulation folder where all the chosen hyperparameters are saved

•NOTE• Execution time can be long, which is why we provide results from previously run simulations
###############################
Task 1.3 - Distributed Training
###############################
file Task1_3.py
-----------------------------------
# Description
This file is related to the Distributed Training.
This file allows the possibility to change the hyperparameter of the distributed training. 
In particular we can chose also among different type of graphs : Binomial,Cyclic,Path,Star, Complete. 
The number of agents and the number of data per agent can be changed

# Figures
Running this file will generate  figures (which will be saved in the imgs/Task 1.3 folder):
• Fig.1 "chose_graph"_graph
• Fig.2 Accuracy evolution during network training
• Fig.3 Evolution of the loss function
• Fig.4 Evolution of the norm of the gradient of the cost function
• Fig.5 Evolution of the consensus error
• Fig.... Confusion Matrix agent i

Furthermore, a text file will be generated inside the simulation folder where all the chosen hyperparameters are saved

•NOTE• Execution time can be long, which is why we provide results from previously run simulations.

###############################
Functions
###############################
file Functions.py
-------------------------------
In this file there are all the main functions needed in each task.
The functions are divided for each task 

###############################
Plot Functions
###############################
file Plt_Functions.py
-----------------------------------
In this file there are all the main Plot functions needed in each task. In particular for task 1.2 and task 1.3.

