""""
=========================================================================================================
                                    DISTRIBUTED AUTONOMOUS SYSTEM
=========================================================================================================
Group 11
Santoro Luca, 0001005415
Spennato Armando, 0001006172

Professor: Giuseppe Notarstefano   Tutor: Ivano Notarnicola  Tutor: Lorenzo Picherri
=========================================================================================================
                        TASK 1: Distributed Classification via Neural Networks
=========================================================================================================
"""

"""
In this file we have implemented all the functions necessary for Task 1_1, Task1_2 and Task1_3.
"""

import numpy as np 
import matplotlib.pyplot as plt
import os # To save simulation
from datetime import datetime # To obtain data and time at each simulation
from pathlib import Path
from collections import deque

import networkx as nx
from termcolor import colored # to change the characteristics of the terminal 

from sklearn.utils import shuffle # For shuffling

################################
""" Save Simulations function"""
################################
def SaveSimulation( specified_subfolder, graph_type=None):
    """
    ==========================================================================
    This function allow to save all the simulations inside the specific folder
    ==========================================================================
    """
    
    # Get the current date and time in the specified format
    timestamp = datetime.now().strftime("%d-%m-%Y_%H.%M")

    # Start from the current directory and move up the directory tree to find 'TASK_1'
    current_dir = Path.cwd()
    task_1_path = None
    for main_folder in [current_dir] + list(current_dir.parents):
        if (main_folder / 'task_1').exists():
            task_1_path = main_folder / 'task_1'
            break
    if task_1_path is None:
        raise FileNotFoundError("The 'task_1' directory was not found.")

    # Create the 'imgs' directory and the specified subfolder within it
    specified_subfolder_path = task_1_path / 'imgs' / specified_subfolder
    specified_subfolder_path.mkdir(parents=True, exist_ok=True)
    
    # Define the folder name based on the presence of a graph_type
    folder_name = f"{graph_type}_{timestamp}" if graph_type else f"Simulation_{timestamp}"

    # Create the full path for the simulation folders
    folder_path = os.path.join(specified_subfolder_path, folder_name)

    # Ensure the folder name is unique by appending a count if needed
    count_sim = 1
    while os.path.exists(folder_path):
        folder_name = f"{graph_type}_{timestamp}_{count_sim}" if graph_type else f"Simulation_{timestamp}_{count_sim}"
        folder_path = os.path.join(specified_subfolder_path, folder_name)
        count_sim += 1

    # Create the unique folder
    os.makedirs(folder_path)

    return folder_path

    
#########################################################################################################
""" *** TASK 1_1 *** """              # Distributed Optimization #
#########################################################################################################

##########################
""" Quadratic Function """
##########################
# We are doing the minimization of a vectorial quadratic function
"""
==============================================================================
Description: Whit this function we have to implement a quadratic function, in
order to have a convex optimization problem with only one global minimum
                  J_i(u) = (1/2)u^T*Q*u + R*u
and its gradient
                  ∇J_i(u) = Q*u + R

Input:
     u --> Optimization variable. u ∈ R^d with d = 2.
     Q_ --> Matrix Q_ ∈ R^(NN)d^2
	   r -->  ∈ R^NN

Output:
    Jval --> Current value of the J(u) at given u
	  Jgrad --> Gradient of J(u) at given u
=================================================================================
"""
def quadratic_fn(u,Q_,r):
	Jval = 0.5*u@Q_@u+r@u
	Jgrd = Q_@u+r
	return Jval, Jgrd
#########################

#########################################################################################################
""" *** TASK 1_2 *** """           # Centralized Training #
#########################################################################################################

#################
'''sigmoid_fn'''
#################
# Activation function
def sigmoid_fn(xi):
  '''
  ==========================================================================================
  With this function we implement our activation function. Inparticular the Sigmoid function:

                      σ(ξ) = = 1/(1 + e^−ξ)

            input --> xi ∈ R

            output --> σ(xi) ∈ R
  ===========================================================================================
  '''
  return 1/(1+np.exp(-xi))

###########################
'''sigmoid_fn_derivative'''
###########################
# Derivative of Activation function
def sigmoid_fn_derivative(xi):
  '''
  ==========================================================================
  With this function we implement the derivative of our activation function:

            input --> xi ∈ R

            output --> dot_σ(xi) = 1/(1 + e−ξ)*(1 − 1/(1 + e−ξ)) ∈ R
  ==========================================================================
  '''
  return sigmoid_fn(xi)*(1-sigmoid_fn(xi))

#######################
'''inference_dynamic'''
#######################
# Inference: x_tp = f(xt,ut)
def inference_dynamics(xt,ut):
  '''
  ===============================================================================================================
  With this function we implement the inference dynamic, with which we are able
  to compute the scalar product between the current state and the current input and apply the activation function.
  In other words the update of each neuron h = 1,..,d_n of layer t + 1.

        x_h,t+1 = σ ((x_t).T u_h,t + u_h,0)  ∈ R

  where u_h,0 is the bias.
  We will use this function in the FORWARD_pass() function

          input:
               xt --> Current state ∈ R^d_c
               ut --> Current input ∈ R^d_n x R^(d_c +1)
          output:
               xtp --> Next state ∈ R^d_n (number of neuron next layer)
  ==================================================================================================================
  '''

  return [sigmoid_fn(xt@ut[ell,1:]+ut[ell,0]) for ell in range(ut.shape[0])]

# The function returns a list with a size equal to the number of neurons in the next layer 
# ut.shape[0] is the number of neurons in the next layer

#####################
''' FORWARD_pass'''
#####################
def FORWARD_pass(uu,x0,T):
  '''
  ===============================================================================================================================
  With this function we implement the Forward propagation. It refers to the calculation
  process and storage of intermediate variables, values output from the layers based on the input data.
  The input X0 provides the initial information which then propagates to the hidden layers and finally
  produces the output y_tilda (our prediction).
  With this function we explore all neurons from the first to the last layer. For this reason, in this function,
  we iterate the inference dynamics for each layer (except the last one) present in the network.
  In particular, for each layer step, using a recurrent approach, we update the trajectory of state xx based on an input sequence.

  input:
       uu --> Input trajectory: u[0],u[1],......,u[T-1] ∈ R^T-1 x R^d_n x R^(d_c + 1)
       x0 --> Initial condition ∈ R^d_c where in this case d_c = 784
       T  --> Number of layer NN
  output:
       xx --> State trajectory: x[0],x[1],......,x[T] ∈ R^T x R^d_c
  ==================================================================================================================================
  '''

  xx = deque(maxlen = T)
  xx.append(x0)

  # we move along the layers
  for t in range(T-1):
    xx.append(inference_dynamics(xx[t],uu[t]))
  return xx

######################
'''adjoint_dynamics'''
######################

# State: lambda_t = A.T lambda_tp
# Output: deltau_t = B.T lambda_tp

def adjoint_dynamics(ltp,xt,ut):
  '''
  ===============================================================================================================================
  With this function we want to apply the adjoint method. So, we compute the derivative of the vector field
  f: R^d_c x R^(d_n x d_c + 1) -> R^d_n (vector function of d component) with respect the state x and with respect the input u :
  input:
         ltp --> Current costate
         xt --> Current State
         ut --> Current Input
  output:
         llambda_t --> next costate
         delta_ut --> loss gradient wrt u_t
  ================================================================================================================================
  '''

  df_dx = np.zeros((len(xt),ut.shape[0]))
  df_du = np.zeros((ut.shape[1]*ut.shape[0],ut.shape[0]))
  dim = np.tile(ut.shape[1],ut.shape[0])
  
  cs_idx = np.append(0,np.cumsum(dim))
  

  for ell in range(ut.shape[0]):
    temp = xt@ut[ell,1:]+ ut[ell,0] # calcolo termine "z" singolo neurone
    Dsigma_ell = sigmoid_fn_derivative(temp)
    df_dx[:,ell] = Dsigma_ell*ut[ell,1:]

    df_du[cs_idx[ell]:cs_idx[ell+1],ell] = Dsigma_ell*np.hstack([1,xt])

  lt = df_dx@ltp        # A'@ltp     lambda_i_t
  Delta_ut_vec = df_du@ltp # B'@ltp
  Delta_ut = np.reshape(Delta_ut_vec,(ut.shape[0],ut.shape[1])) # delta_u

  return lt, Delta_ut

# A deque is a data structure in Python that represents a queue with upper bounds on its length.
# When new elements are added to the deque and exceed the specified maximum length, the oldest elements are removed.

######################
''' BACKWARD_pass '''
######################

def BACKWARD_pass(xx,uu,llambdaT,T):
  '''
  ============================================================================================================

  input:
           xx --> State Trajectory : x[1],x[2],......,x[T]
           uu --> input Trajectory : u[0],u[1],......,u[T-1]
           llambdaT --> Terminal Condition
           T --> Number of layer NN
  output:
          llambda --> Costate Trajectory
          delta_u --> Costate output, i.e, the loss gradient
  ==============================================================================================================
  '''

  llambda =  deque (maxlen = T)
  Delta_u = deque (maxlen = T-1)

  llambda.append(np.array([llambdaT]))
  for t in reversed(range(T-1)):
    ll_t, du_t = adjoint_dynamics(llambda[0],xx[t],uu[t])

    Delta_u.appendleft(du_t) # appendo all'inizio della coda
    llambda.appendleft(ll_t)

  return llambda, Delta_u

# llambda : landa i t
# Delta_u : delta i t k delle slide


################################
'''BCE - Binary cross Entropy'''
################################

def BCE(pred,y):
  '''
  =====================================================================================
  With this function we implement the BCE loss function or logistic loss.
  It is Function that compares the target and predicted output values.

     J = BCE = (y^i * log(Φ(u, D^i)) + (1 − y^i) log(1 − Φ(u, D^i)))

  where Φ is the shooting map

            input  -->    predicted label ∈ R
                          Current (Target) label ∈ R

            output -->   loss value of an item ∈ R
                         Grad_loss value ∈ R
  ======================================================================================
  '''
  epsilon = 1e-6 # The use of an epsilon value in this context is known as "smoothing" or "stabilization."
  #It's done to prevent taking the logarithm of zero, which can lead to numerical issues.
  loss = y* np.log(pred+epsilon)+ (1-y)*(np.log(1- pred + epsilon))
  Grad_loss = -(y / (pred + epsilon)) + (1 - y)/ (1 - pred + epsilon) # Gradient
  # - in the return value loss, because we wanto to minimize the loss function.
  return -loss, Grad_loss



#########################################################################################################
""" *** TASK 1_3 *** """           # Distibuted Training #
#########################################################################################################

######################
'''GRAPH_GENERATION'''
######################
def graph_generation(NN, type, show_G):
    """
    =========================================================================================
    This function allows defining different graph types and showing the chosen graph.
                      input: NN --> Number of agents 
                      Type --> Graph type 
                      show_G --> Flag to show the plot
                      
                      output: G --> Chosen graph
    =========================================================================================
    """

    ''' -> BINOMIAL graph <- '''
    if type == "Binomial":
        # Create a Binomial Graph with N nodes
        #graph_type = "Binomial"
        p_ER = 0.5
        G = nx.binomial_graph(NN, p_ER)
        print(colored('\nChosen graph: BINOMIAL GRAPH\n', 'green', attrs=['bold']))

    ''' -> PATH graph <- '''
    if type == "Path":
        # Create a Path Graph with N nodes
        #graph_type = "Path"
        print(colored('\nChosen graph: PATH GRAPH\n', 'green', attrs=['bold']))
        G = nx.path_graph(NN)  # we obtain a path graph with N nodes

    ''' -> STAR graph <- '''
    if type == "Star":
        # Create a Star Graph with N nodes
        #graph_type = "Star"
        print(colored('\nChosen graph: STAR GRAPH\n', 'green', attrs=['bold']))
        G = nx.star_graph(NN - 1)

    ''' -> CYCLIC graph <- '''
    if type == "Cycle":
        # Create a Cycle Graph with N nodes
        #graph_type = "Cycle"
        print(colored('\nChosen graph: CYCLE GRAPH\n', 'green', attrs=['bold']))
        G = nx.cycle_graph(NN)

    ''' -> COMPLETE graph <- '''
    if type == "Complete":
        # Create a Complete Graph with N nodes
        #graph_type = "Complete"
        print(colored('\nChosen graph: COMPLETE GRAPH\n', 'green', attrs=['bold']))
        G = nx.complete_graph(NN)

    '''----> *** Graph drawing *** <----'''
    if show_G == True:
        plt.figure()
        plt.title(r"Graph")
        nx.draw(G, with_labels=True)
    return G

######################
'''Adjacency matrix'''
######################

def Adj_matrix(G, NN, show_Adj):
    '''
    ===================================================================================
    With the following function we define the Adjiacency matrix starting from a graph G.
                Inputs: G --> Graph 
                        NN --> Number of agents
                        show_Adj --> Flag in order to visualize the matrix
                
                Output: Adj --> Adjiacency matrix
    ====================================================================================
    '''
    while True:
        # we extract the adj matrix
        Adj = nx.adjacency_matrix(G).toarray()  # Adjacency matrix of a graph
        degree = np.sum(Adj, axis=0)

        # we check connectivity
        I_NN = np.eye(NN)
        test = np.linalg.matrix_power(Adj + I_NN, NN)
        if np.all(test > 0):
            print('The graph is connected\n')
            break
        else:
            print('The graph is NOT connected')
            print('--------------------------')
            print('Try again:\n')

    # To see the Adj Matrix
    if show_Adj:
        print(f'Adjacency matrix graph:\n {Adj}')
        print(f'Degree:\n{degree}')

    return Adj


#####################
'''Weighted Matrix'''
#####################
def weighted_matrix(Adj,NN,ww_show):
  '''
  ===============================================================================================
  With this function we define the weighted matrix and check the colum and row stochasticity.
  The function takes the following inputs:
                    Adj --> Adjiacency matrix
                    NN --> number of agents (Node)
                    ww_show --> flag to show the matrix
              and Outputs:
                    ww --> Weighted Adjiacency matrix
  ================================================================================================
  '''
  print(colored('\nChosen weights: Metropolis-Hastings Weights\n','green',attrs=['bold']))
  WW = np.zeros((NN,NN))
  degree = np.sum(Adj, axis=0)
  for ii in range(NN):
    #Nii = list(G.neighbors(ii))
    Nii = np.nonzero(Adj[ii])[0]

    for jj in Nii:
       #WW[ii,jj] = 1/(1+max(degree[ii],degree[jj]))
       WW[ii,jj] = 1/(1+np.max([degree[ii],degree[jj]]))

    WW[ii,ii] = 1-np.sum(WW[ii,:])

  if ww_show == True:
    print(colored('\nWeighted Adjiacency matrix\n','green',attrs=['bold']))
    print(f'WW:\n{WW}')

  with np.printoptions(precision=4, suppress=True):
      print('\nCheck Stochasticity:\n row: {} \n column {}'.format(
      np.sum(WW,axis=1),
		  np.sum(WW,axis=0)))

  return WW

#####################################
'''Splitting Data Among the Agents'''
#####################################
def split_data_agents (NN,X_train,y_train,N_train_data_agent,show):
  """
  =========================================================================================
  With this function we split data and labels among the agents:
                input:  NN --> number of agents
                        X_train --> all train data available
                        y_train --> train labels available
                        N_train_data_agent --> number of train data for each agent
                        show --> to show the array dimension

                output: X_train_agent --> train data for each agent
                        y_train_agent --> train labels for each agent
  The function randomly generates indices based on the specified range, thus guaranteeing
  a random selection of data for each agent. This contributes to a distribution
  random and varied data between agents, improving the representativeness of the data set
  for each agent in the context of a distributed machine learning application.
  =========================================================================================
  """

  # We check that all data dimensions are correctly set:
  if ((NN * N_train_data_agent) >= len(X_train)):
        print("\nThe selected train data size for each agent is too big")
        print(f"Try again: AGENT_train_data * NN must not exceed {len(X_train)}")
        exit()

  # Initialize arrays to store data and labels for each agent
  # Train
  X_train_agent = np.empty((NN, N_train_data_agent, X_train.shape[1]))
  y_train_agent = np.empty((NN, N_train_data_agent),dtype=int)
  

  ######################
  '''Shuffling again '''
  ######################
  # If we want to mix the training data again, 
  # before splitting among the agents
  if True:
    # Shuffling training data and corresponding labels
    X_train, y_train = shuffle(X_train, y_train, random_state=42)

  ######################

  # Splitting the TRAIN set between agents:
  for agent in range(NN):
      # Genera indici casuali senza sovrapposizione
      available_indices = set(range(len(X_train))) # set called with indices ranging from 0 to the length of X_train
      selected_indices = np.random.choice(list(available_indices), size=N_train_data_agent, replace=False)

      X_train_agent[agent] = X_train[selected_indices]
      y_train_agent[agent] = y_train[selected_indices]
    
      # utilizzando np.random.choice con replace=False per garantire che gli indici selezionati 
      # siano unici. Utilizzo un set (available_indices) per gestire gli indici disponibili e assicurarmi che non ci siano sovrapposizioni

  if show:
    print("Dimention of data and input label for each agent ")
    print(f"\nTrain data size: {X_train_agent.shape}")
    print(f"\nTrain label size: {y_train_agent.shape}")

    # To visualize the number of 0/1 labels given as input to each agent
    for i in range(NN):
        unique_labels, counts = np.unique(y_train_agent[i].astype('int32'), return_counts=True)

        print(f'\nAgent {i} - Unique label counts:')
        for label, count in zip(unique_labels, counts):
            print(f'Label {label}: {count} occurrences')

  return X_train_agent,y_train_agent
##########################




