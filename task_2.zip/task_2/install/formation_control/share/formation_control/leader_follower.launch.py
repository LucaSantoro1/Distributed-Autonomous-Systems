""""
=========================================================================================================
                                    DISTRIBUTED AUTONOMOUS SYSTEM
=========================================================================================================
Group 11
Santoro Luca, 0001005415
Spennato Armando, 0001006172

Professor: Giuseppe Notarstefano   Tutor: Ivano Notarnicola  Tutor: Lorenzo Picherri
=========================================================================================================
                        TASK 2: Formation Control - Moving Formation and Leader control 
=========================================================================================================
"""

from launch import LaunchDescription
from ament_index_python.packages import get_package_share_directory
from launch_ros.actions import Node
import os
import numpy as np
np.random.seed(42)

visu_frequency = 100 #[Hz]

#####################################################################################
def delete_file_folder(folder_path):
    """
    ==========================================================================
    This function deletes files in the specified path.
    ==========================================================================
    """

    try:
        # List of files in the folder
        files = os.listdir(folder_path)

        # Iterate through the files and delete them
        for file in files:
            percorso_file = os.path.join(folder_path, file)
            os.remove(percorso_file)
        
        print(f'\nFiles successfully deleted from {folder_path} folder.\n')

    except Exception as e:
        print(f"\nAn error occurred: {e}\n")

####################################################################################


#####################################################################################
def get_distances_matrix(shape):
    
    """
    =====================================================================================
    Function to define the distance matrix:Weight matrix to control inter-agent distances.
    The function take as input a string that identify the selected shape and return the 
    associated distance matrix and the necessary number of agents
    =====================================================================================
    """
     
    "2D"
    # Minimally rigid 2*N-3 (only for regular polygons)
    "3D" 
    # Minimally rigidy Nn-n(n+1)/2  where N = # agents; n = dim agents

    if shape == 'pentagon':
        nn = 5
        L = 2
        D = ((np.sqrt(5)+1)/2)*L 

        distances = [[0,    L,      D,    D,    L],
                     [L,     0,      L,    0,    D],
                     [D,     L,      0,    L,    0],     
                     [D,     0,      L,    0,    L],         
                     [L,     D,      0,    L,    0]]

        # complete connection ----> all agent are able to avoid collision
        #distances = [[0,    L,      L,    0,    D],
        #             [L,     0,      D,    L,    D],
        #             [L,     D,      0,    D,    L],     
        #             [0,     L,      D,    0,    L],         
        #             [D,     D,      L,    L,    0]]

        print(f'\nShape: {shape}; Agent required: {nn}\n')

    elif shape == 'square':
        nn = 4 # number of agents
        L = 4
        H = np.sqrt(2)*L
        
        # complete connection (all agent ara able to avoid collision)
        #distances = [[0, L, H, L],
        #                [L, 0, L, H],
        #                [H, L, 0, L],
        #                [L, H, L, 0]]

        distances = [[0, L, H, L],
                     [L, 0, 0, H],
                     [H, 0, 0, L],
                     [L, H, L, 0]]
        


        print(f'\nShape: {shape}; Agent required: {nn}\n')

    elif shape == 'cube':
            nn = 8
            L = 2
            d = np.sqrt(2)*L # square diagonal
            D = np.sqrt(3)*L # internal diagonal
            distances = [[0,    L,      d,    L,    D,	 0,	  L,  	d],
                        [L,     0,      L,    0,    d, 	 D,	  0, 	L],
                        [d,     L,      0,    L,    L,   d,   D,    0],     
                        [L,     0,      L,    0,    0,   L,   d,    D],         
                        [D,     d,      L,    0,    0,   L,   d,    L], 
                        [0,     D,      d,    L,    L,	 0,	  L,  	0],
                        [L,     0,      D,    d,    d, 	 L,	  0, 	L],
                        [d,     L,      0,    D,    L,   0,   L,    0]]
        
            print(f'\nShape: {shape}; Agent required: {nn}\n')
    
    elif shape == 'pyramid':
            nn = 5
            L = 2 # base edge
            H = 3
            D = L*np.sqrt(2) # diagonal base
            l = np.sqrt((H**2)+(L**2)/2) # lateral edge

            distances = [[0,    L,      D,    0,    l],
                        [L,     0,      L,    D,    l],
                        [D,     L,      0,    L,    l],     
                        [0,     D,      L,    0,    l],       
                        [l,     l,      l,    l,    0]]
    
            print(f'\nShape: {shape}; Agent required: {nn}\n')

    elif shape == 'pentagonalprism':
            nn = 10
            L = 2
            dp = L*(np.sqrt(5)+1)/2    # diagonal pentagon
            dl = L *np.sqrt(2)         # diagonal square
            D = np.sqrt(L**2 + dl**2)  # internal diagonal

            distances = [[0,     L,      dp,    dp,     L,    L,    dl,    D,    D,    dl],
                        [L,     0,      L,    0,     dp,    dl,    L,    dl,    D,    D],
                        [dp,     L,      0,    L,     0,    D,    dl,    L,   dl,    D],
                        [dp,     0,      L,    0,     L,    D,    D,    dl,   L,   dl],
                        [L,     dp,      0,    L,     0,    dl,   D,   D,   dl,    L],
                        [L,     dl,      D,    D,     dl,    0,    L,    dp,    dp,   L],
                        [dl,     L,      dl,    D,     D,    L,    0,    L,    0,   dp],
                        [D,     dl,      L,    dl,     D,    dp,    L,    0,    L,   0],
                        [D,     D,      dl,   L,     dl,    dp,    0,    L,    0,   L],
                        [dl,     D,      D,    dl,     L,    L,    dp,    0,    L,   0]]
            
            print(f'\nShape: {shape}; Agent required: {nn}\n')

    elif shape == 'A':
        nn = 6   # number of agents
        L = 2
        ang = np.deg2rad(120)
        D = ((L/2)**2 + L**2 - 2*(L/2)*L*np.cos(ang))**0.5
        S = (L**2 - (L/2)**2)**0.5
        DL = 2*L
        LD = 0
        distances = [[ 0,      L,    2*L,      0,     LD,     DL],
                    [  L,      0,      L,    L/2,     L,     LD],
                    [2*L,      L,      0,      S,     L,    2*L],     
                    [  0,    L/2,      S,      0,   L/2,      0],     
                    [  LD,      L,      L,    L/2,     0,      L],     
                    [ DL,     LD,    2*L,      0,     L,     0]]
             
        print(f'\nShape: {shape}; Agent required: {nn}\n')

    else:
        # shape errors
        print("\nShape formation not supported. Change it.\n")
        print("Possible shapes: pentagon,square,cube,pyramid,pentagonalprism,A\n")
    
    return distances,nn 
##################################################


path1= "_csv_file_leader_follower/simulation" 
path2= "_csv_file_leader_follower/target"  

# we delete all the files inside the _csv_file_leader_follower/simulation and /target folder, 
# every time we launch.
delete_file_folder(path1)
delete_file_folder(path2)


print("-------------------------------------------------------------------")
print("Task 2.3 - Moving Formation and Leader control")
print("-------------------------------------------------------------------")

def generate_launch_description():

    ############
    "Parameters"
    ############
    MAXITERS = 500
    COMM_TIME = 5e-2 # communication time period
    n_x = 3 # dimension of x_i 

    # we get information from the terminal
    # shape fromation definition
    shape_formation = os.environ.get('shape_formation', 'square')
    # target definition 
    target_type = os.environ.get('target_type', 'point') 
    print(f'\nChosen target: {target_type}')

    # we get the distance matrix and the relative number of nodes
    distances,NN = get_distances_matrix(shape_formation)
    distances = np.asarray(distances) # convert list to numpy array
    # Adjacency matrix
    Adj = distances > 0

    ############################
    """ formation parameters """
    ############################

    """ One leader """
    # we choose the leader of our formation
    # It's the blue one agent in the desired formation
    id_leader = 2 # one leader 
    print(f'\nThe leader is the agent {id_leader}')
    
    #####################
    """ Inizialization"""
    #####################
    
    # definite initial positions (initial state)
    x_init = 3*np.random.rand(n_x*NN,1) 

    """ Target """

    # define the initial target positions 
    x_des = (np.zeros(n_x)).astype(float)
    x_des=x_des.tolist()

    if shape_formation in ['pentagon', 'square', 'A']:
        #Set the third component to zero because we are considering a planar formation
        x_init[2::n_x] = 0  #selezionerà ogni terzo elemento a partire dall'indice 2 e li imposterà a zero 

    launch_description = [] # Append here your nodes
    # we will append a set of agents/nodes

    ################################################################################
    # RVIZ
    ################################################################################

    # initialize launch description with rviz executable
    rviz_config_dir = get_package_share_directory('formation_control')
    rviz_config_file = os.path.join(rviz_config_dir, 'rviz_config.rviz')

    # launch Rviz node
    launch_description.append(
        Node(
            package='rviz2', 
            executable='rviz2', 
            arguments=['-d', rviz_config_file],
            ))

    ################################################################################

    for ii in range(NN):
        distances_ii = distances[:, ii].tolist()
        N_i = np.nonzero(Adj[:, ii])[0].tolist() # N_i contiene gli indici degli elementi non nulli nella colonna ii della matrice Adj convertiti in una lista.
        
        print(f'Neighbours of {ii} are: {N_i}\n')

        ii_index = ii*n_x + np.arange(n_x)
        x_init_ii = x_init[ii_index].flatten().tolist()
    

        # we need to add an object created with the node constructor
        launch_description.append(
            Node(
                package='formation_control',
                namespace =f'agent_{ii}',
                executable='leader_follower_agent',
                # we specify the set of parameter which is a list
                # which contains a dictionary 
                parameters=[{ # dictionary
                                'agent_id': ii, 
                                'neigh': N_i, 
                                'x_init': x_init_ii,
                                'max_iters': MAXITERS,
                                'communication_time': COMM_TIME,
                                'dist' : distances_ii,
                                'shape_formation': shape_formation,
                                'target_position':x_des,
                                'id_leader_formation':id_leader,
                                'target_type':target_type,
                                }],
                # just for showing the results on the screen
                output='screen',
                prefix=f'xterm -title "agent_{ii}" -hold -e',
            ))
        # launch visualizer
        launch_description.append(
            Node(
                package='formation_control', 
                namespace='agent_{}'.format(ii),
                executable='visualizer', 
                parameters=[{
                                'agent_id': ii,
                                'node_frequency': visu_frequency,
                                'id_leader_formation':id_leader,
                                }],
            ))
        #launch visualizer_target
        launch_description.append(
        Node(
            package='formation_control', 
            namespace='target_position',
            executable='visualizer_target', 
            parameters=[{
                            'node_frequency': visu_frequency,
                            }],
        ))

    return LaunchDescription(launch_description)