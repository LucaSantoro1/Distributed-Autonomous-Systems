""""
=========================================================================================================
                                DISTRIBUTED AUTONOMOUS SYSTEM
=========================================================================================================
Group 11
Santoro Luca, 0001005415
Spennato Armando, 0001006172

Professor: Giuseppe Notarstefano   Tutor: Ivano Notarnicola  Tutor: Lorenzo Picherri
=========================================================================================================
                        TASK 2: Formation Control - Obstacle Avoidance
=========================================================================================================
"""

from termcolor import colored # to change the characteristics of the terminal 
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.animation import FuncAnimation
import os
#####################################################################################################################################
print(colored('\n-------------------------------------------------------------------------------------\n','red',attrs=['bold']))
print(colored('\n*** TASK 2: Formation Control - Obstacle Avoidance ***\n','red',attrs=['bold']))
####################################################################################################################################

############
""" Flag """
############
animation = True # to abilitate the animation

default_folder = True # to decide which folder to take the files from 
# Note:
# default folder    --> to view the default simulations (default_folder = True)
# simulation folder --> to view the current Rviz simulation (default_folder = False)
default_type = 'square' # possible folder 'square','cube'.
print(f'\nChosen formation: {default_type}\n')
##################################################################


###################################################################
if default_folder:
    # we consider the default folder inside _csv_file_formation folder
    if default_type == 'square':
        _, _, files = next(os.walk("./_csv_file_obstacle_avoidance/default/square")) 
        NN = len(files) 
        xx_csv = {}
        Tlist = []

        for ii in range(NN):
            xx_csv[ii] = np.genfromtxt("_csv_file_obstacle_avoidance/default/square/agent_{}.csv".format(ii), delimiter=',').T
            Tlist.append(xx_csv[ii].shape[1])

        # We load the Obstacle barrier force (potential) value from the csv file 
        _, _, files = next(os.walk("./_csv_file_obstacle_avoidance/default/square_barrier_obst")) 
        NN = len(files)
        barrier_obst_csv = []
        for ii in range(NN):
            barrier_obst_csv.append( np.genfromtxt("_csv_file_obstacle_avoidance/default/square_barrier_obst/barrier_agent_{}.csv".format(ii), delimiter=','))

        # load target position
        target_position = np.genfromtxt("_csv_file_obstacle_avoidance/default/square_target/target_agent_2.csv", delimiter=',')

        # load obstacle position
        obstacle_position = np.genfromtxt("_csv_file_obstacle_avoidance/default/square_obst/obst_agent_2.csv", delimiter=',')
    
    elif default_type == 'cube':
        _, _, files = next(os.walk("./_csv_file_obstacle_avoidance/default/cube")) 
        NN = len(files)
        xx_csv = {}
        Tlist = []

        for ii in range(NN):
            xx_csv[ii] = np.genfromtxt("_csv_file_obstacle_avoidance/default/cube/agent_{}.csv".format(ii), delimiter=',').T
            Tlist.append(xx_csv[ii].shape[1])

        # We load the obstacle barrier force (potential) value from the csv file 
        _, _, files = next(os.walk("./_csv_file_obstacle_avoidance/default/cube_barrier_obst")) 
        NN = len(files)
        barrier_obst_csv = []
        for ii in range(NN):
            barrier_obst_csv.append( np.genfromtxt("_csv_file_obstacle_avoidance/default/cube_barrier_obst/barrier_agent_{}.csv".format(ii), delimiter=','))

        # load target position
        target_position = np.genfromtxt("_csv_file_obstacle_avoidance/default/cube_target/target_agent_2.csv", delimiter=',')

        # load obstacle position
        obstacle_position = np.genfromtxt("_csv_file_obstacle_avoidance/default/cube_obst/obst_agent_2.csv", delimiter=',')
    
    else:
        # folder errors
        print("\nFolder not found.\n")
        print("Possible folder: cube,square\n")
else:
    # we consider the simulation folder inside _csv_file_formation folder
    _, _, files = next(os.walk("./_csv_file_obstacle_avoidance/simulation")) 
    NN = len(files)
    xx_csv = {}
    Tlist = []

    for ii in range(NN):
        xx_csv[ii] = np.genfromtxt("_csv_file_obstacle_avoidance/simulation/agent_{}.csv".format(ii), delimiter=',').T
        Tlist.append(xx_csv[ii].shape[1])

    # We load the barrier force (potential) value from the csv file 
    _, _, files = next(os.walk("./_csv_file_obstacle_avoidance/barrier_obst")) 
    NN = len(files)
    barrier_obst_csv = []
    for ii in range(NN):
        barrier_obst_csv.append( np.genfromtxt("_csv_file_obstacle_avoidance/barrier_obst/barrier_agent_{}.csv".format(ii), delimiter=','))    

    # load target position
    target_position = np.genfromtxt("_csv_file_obstacle_avoidance/target/target_agent_2.csv", delimiter=',')

    # load obstacle position
    obstacle_position = np.genfromtxt("_csv_file_obstacle_avoidance/obst/obst_agent_2.csv", delimiter=',')
#################################################################################
n_x = xx_csv[ii].shape[0]
print(f"\nThe current dimention is: {n_x}\n")
Tmax = min(Tlist)

xx = np.zeros((NN * n_x, Tmax))

for ii in range(NN):
    for jj in range(n_x):
        index_ii = ii * n_x + jj
        xx[index_ii, :] = xx_csv[ii][jj][:Tmax]  # utile per rimuovere gli ultimi campioni

##########################################################################################
        
##########################
"""Barrier obstacle plot"""
##########################

for ii in range(NN):
    barrier_ii = barrier_obst_csv[ii] 

    iter = np.arange(len(barrier_obst_csv[ii])) #  iterazioni 
   
    plt.plot(iter,barrier_ii)

    plt.xlabel('iteration')
    plt.ylabel('Barrier Force ')
    plt.title(f'Obstacle Barrier Force Agent {ii} ')
    plt.grid()       
    #plt.legend()   
    plt.show()



##################################################################àààààà   
'''
if n_x == 2:
    # Plot 2D
    print("\nPlot Formation 2D\n")
    plt.figure()
    for x in xx:
        plt.plot(range(Tmax), x)

    block_var = False if n_x < 3 else True
    plt.show(block=block_var)

    # Animazione 2D
    if animation:
        print("\n2D Formation Animation\n")
        fig_anim = plt.figure()
        dt = 3  # sottocampionamento dell'orizzonte del grafico

        def update(frame):
            plt.clf()
            xx_tt = xx[:, frame].T
            for ii in range(NN):
                index_ii = ii * n_x + np.arange(n_x)
                xx_ii = xx_tt[index_ii]
                plt.plot(xx_ii[0], xx_ii[1], marker='o', markersize=15, fillstyle='none', color='tab:red')

            axes_lim = (np.min(xx) - 1, np.max(xx) + 1)
            plt.xlim(axes_lim)
            plt.ylim(axes_lim)
            plt.plot(xx[0:n_x * NN:n_x, :].T, xx[1:n_x * NN:n_x, :].T)

            plt.axis('equal')

        animation = FuncAnimation(fig_anim, update, frames=range(0, Tmax, dt), repeat=False)
        plt.show()
'''
if n_x == 3:
    print("\nPlot Formation 3D\n") 
    # Plot 3D
    fig_3D = plt.figure()
    ax = fig_3D.add_subplot(111, projection='3d')

    for ii in range(NN):
        x = xx[ii * n_x:(ii + 1) * n_x, :]
        ax.plot(x[0, :], x[1, :], x[2, :])
            
        # Add the dots to the final point of the curves
        ax.scatter(x[0, -1], x[1, -1], x[2, -1], marker='o')

        # for target
        ax.scatter(target_position[-1, 0], target_position[-1, 1], target_position[-1, 2], color='red', marker='*', s=100)
        # for obstacle
        ax.scatter(obstacle_position[-1, 0], obstacle_position[-1, 1], obstacle_position[-1, 2], color='red', marker='o', s=100)

        ax.set_xlabel('X')
        ax.set_ylabel('Y')
        ax.set_zlabel('Z')

    ax.set_title('Formation trajectories in 3D')
    plt.show()

    if animation:
        print("\n3D Formation animation\n")
        fig_animation_3D = plt.figure()
        ax = fig_animation_3D.add_subplot(121, projection='3d')  # First subplot for the trajectories
        ax_scatter = fig_animation_3D.add_subplot(122, projection='3d')  # Second subplot for the scatter plot

        def update(frame):
            '''This function updates a 3D animation of agent formation trajectories'''
            # we clean up the 3D axis before drawing new data for the current frame of the animation
            ax.cla() # cla() is a metod that clear the axis removing all artists (lines, texts, etc.) present on it.
            ax_scatter.cla()

            for ii in range(NN):
                x = xx[ii * n_x:(ii + 1) * n_x, :frame]
                # Plot the trajectories of agents in 3D space for each frame up to the current frame
                ax.plot(x[0, :], x[1, :], x[2, :], linestyle='-')

                # Marker last frame
                x_marker = xx[ii * n_x:(ii + 1) * n_x, frame-1]
                # Add a marker for the last frame of each agent's trajectory.
                ax.scatter(x_marker[0], x_marker[1], x_marker[2], s=50, label=f'Agent {ii}')

                # Scatter plot in the SECOND SUBPLOT
                # Create a scatter plot of agents' positions in 3D space for each frame.
                ax_scatter.scatter(x[0, :], x[1, :], x[2, :], label=f'Agent {ii}')

                # Connect points to the last frame in the scatter plot
                for ii in range(NN):
                    if frame > 0:
                        x_last_frame = xx[ii * n_x:(ii + 1) * n_x, frame-1]
                        ax_scatter.plot([x[0, -1], x_last_frame[0]], [x[1, -1], x_last_frame[1]], [x[2, -1], x_last_frame[2]], linestyle='--', color='gray')

            # for target
            frame_idx = min(frame, len(target_position) - 1)
            target_positions = target_position[frame_idx]
            ax.scatter(target_positions[0], target_positions[1], target_positions[2], color='red', marker='*', s=100,label='target')
            ax_scatter.scatter(target_positions[0], target_positions[1], target_positions[2], color='red', marker='*', s=100,label='target')
            

            # for obstacle
            frame_idx = min(frame, len(obstacle_position) - 1)
            obstacle_positions = obstacle_position[frame_idx]
            ax.scatter(obstacle_positions[0], obstacle_positions[1], obstacle_positions[2], color='red', marker='o', s=100,label='obstacle')
            ax_scatter.scatter(obstacle_positions[0], obstacle_positions[1], obstacle_positions[2], color='red', marker='o', s=100,label='obstacle')
            

            # Set titles and labels
            ax.set_title('Formation trajectories in 3D',fontsize=12, fontweight='bold')
            ax_scatter.set_title('3D formation',fontsize=12, fontweight='bold')
            ax.set_xlabel('X',fontsize=12, fontweight='bold')
            ax.set_ylabel('Y',fontsize=12, fontweight='bold')
            ax.set_zlabel('Z',fontsize=12, fontweight='bold')
            ax_scatter.set_xlabel('X',fontsize=12, fontweight='bold')
            ax_scatter.set_ylabel('Y',fontsize=12, fontweight='bold')
            ax_scatter.set_zlabel('Z',fontsize=12, fontweight='bold')

            # Add legends
            ax.legend()
            ax_scatter.legend()

            # Use the same animation function for both subplots
    
        animation = FuncAnimation(fig_animation_3D, update, frames=range(0, Tmax), repeat=False)
        plt.show()

  