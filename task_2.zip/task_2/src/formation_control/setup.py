from setuptools import setup
from glob import glob

package_name = 'formation_control'
scripts = ['the_agent', 'visualizer','collision_agent','visualizer_target','leader_follower_agent','obstacle_agent','visualizer_obstacle']

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name, glob('launch/*.launch.py')),
        # to have the ability to run the ros2 launch file without
        #  moving inside the launch folder
        ('share/' + package_name, glob('resource/*.rviz')),
        ('share/' + package_name + '/meshes', glob('meshes/*.stl')),  # Aggiunto questo blocco per la cartella meshes
        
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='luca',
    maintainer_email='luca@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            '{1} = {0}.{1}:main'.format(package_name, script) for script in scripts
        ],
    },
)
# In this file we tell at ROS2  that we have nodes