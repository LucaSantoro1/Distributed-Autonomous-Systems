""""
=========================================================================================================
                                    DISTRIBUTED AUTONOMOUS SYSTEM
=========================================================================================================
Group 11
Santoro Luca, 0001005415
Spennato Armando, 0001006172

Professor: Giuseppe Notarstefano   Tutor: Ivano Notarnicola  Tutor: Lorenzo Picherri
=========================================================================================================
                        TASK 2: Formation Control - Obstacle Avoidance
=========================================================================================================
"""

from time import sleep
import numpy as np 
import rclpy # we use ROS2 Python implementation
from rclpy.node import Node # take the Node class
from std_msgs.msg import Float32MultiArray as MsgFloat # because we want to use numbers (array of float number)
np.random.seed(42)



def formation_update_obst(dt, x_i, neigh, data, dist,agent_id,id_leader,x_des,x_obs):
    """
    ============================================================================================
     This function updates the state of an agent in a formation control
     system using a simple Euler integration scheme. 
     It implements a formation control law where the agent adjusts its position 
     based on the positions of its neighbors. In particular, The function iterates
     over the neighbors, calculates some forces (potential) as  dV_ij, 
     dV_ij_barrier and dbf_obsts based on the difference
     in positions, and updates the agent's state (x_i) using the Euler integration method.
            Inputs:    
                    dt    = discretization step
                    x_i   = state pf agent i
                    neigh = list of neihbors
                    data  = state of neighbors
                    dist  = coefficient for formation control law 
                    agent_id =  agent identification number
                    id_leader = leader identification number
                    x_des = desired position
                    x_obst = obstacle position
            Output: x_i   = state pf agent i
                    barrier_obst_values  = list of force Values
    ==============================================================================================
    """

    xdot_i = np.zeros(x_i.shape)
    dV_ij = np.zeros(x_i.shape)         # Formation force
    dV_ij_barrier = np.zeros(x_i.shape) # Barrier force
    dbf_obsts =np.zeros(x_i.shape)      # Barrier force obstacle

    barrier_obst_values = []

    ###############
    gain_barr = 0.2 # In order to regulate the intensity of the barrier force
    ###############
    ##############
    gain_obst_barr = 10 # in order to regulate the intensity of the barrier force (1 cube)
    ##############

    for j in neigh:
        # Extract the positions of the neighbours og agent i
        x_j = np.array(data[j].pop(0)[1:])

        # For collision avoidance
        if np.linalg.norm(x_i-x_j)<= 1.5:
            dV_ij_barrier = gain_barr * 2*(x_i - x_j)/((np.linalg.norm(x_i - x_j))**2)
        else:
            dV_ij_barrier = np.zeros(3)

        # For obstacle avoidance 
        if np.linalg.norm(x_i-x_obs)<=1.5:
           dbf_obsts = gain_obst_barr*2*(x_i-x_obs)/((np.linalg.norm(x_i-x_obs))**2)
        else:
            dbf_obsts = np.zeros(3)
        
        barrier_obst_values.append(np.linalg.norm(dbf_obsts)) # we store the obstacle barrier force

       
        dV_ij = ((x_i - x_j).T@(x_i - x_j) - dist[j]**2)*(x_i - x_j)
        
        # To view the magnitude of the forces
        #print(f'Barrier FC: {np.linalg.norm(dV_ij_barrier)}; Barrier FO: {np.linalg.norm(dbf_obsts)}; Formation F: {np.linalg.norm(dV_ij)}; neighbor: {j}')
        
        xdot_i += - (dV_ij-dV_ij_barrier-dbf_obsts)
       
    # Forward Euler
    x_i += dt*xdot_i
    
    # set the gain for the proportional action
    ############
    gain_p = 10 
    ############
    if agent_id==id_leader: 
        print(f'\nagent_id:{agent_id},id_leader:{id_leader}\n')
        prop_action= gain_p*(x_i - x_des)

        # Forward Euler
        x_i += -dt*prop_action
    
    return x_i, barrier_obst_values 


######################################################################################################
def generate_trajectory(shape_formation,trajectory_target, kk):
    """
    ==========================================================
    This function generates the trajectory chosen as target.
    Parametric formulas are used.
    The function takes the following
    input:
        shape_formation:
        trajectory_target: in orget to define the trajectory
        kk: iteration
    output:
        x_target: trajectory at iteration kk
    ==========================================================
    """
    x_target = np.zeros(3)

    if trajectory_target == 'point':
        # P = (-2,-1)   in 2D square, pentagon, A  # A da rivedere
        # p = (-2,-1,2) in 3D cube, pentagonalprism, pyramid
        x_target[0] = -2 
        x_target[1] = -1

        # if we chose a 2D formation the target point will be on the plane 
        if shape_formation in ['pentagon', 'square', 'A']:
            x_target[2] = 0
        else:
            x_target[2] = 2

    elif trajectory_target == 'circle':
        if shape_formation == 'square':
            """
            center: (-2,-2); radius: 0.5
            """
            x_target[0] = -2 +  0.5*np.cos(0.05*kk)
            x_target[1] = -2 +  0.5*np.sin(0.05*kk)
        
        elif shape_formation in ['pentagon', 'pyramid']:
            """
            center: (-1,-1); radius: 0.5
            """
            x_target[0] = -1 +  0.5*np.cos(0.05*kk)
            x_target[1] = -1 +  0.5*np.sin(0.05*kk)

        elif shape_formation in ['cube','pentagonalprism']: 
            """
            center: (-2,2); radius: 0.5
            """
            x_target[0] = -2 +  0.5*np.cos(0.05*kk) 
            x_target[1] = 2 +  0.5*np.sin(0.05*kk)

        else:
            x_target[0] = -1 +  0.5*np.cos(0.05*kk) 
            x_target[1] = 2 +  0.5*np.sin(0.05*kk)

        # if we chose a 2D formation the target point will be on the plane 
        if shape_formation in ['pentagon', 'square', 'A']:
            x_target[2] = 0
        else:
            x_target[2] = 2

    elif trajectory_target == 'ellipse':
        if shape_formation == 'square':
            """
            center: (-2,-2); major axis:0.5 ;minor axis:0.25
            """
            x_target[0] = -2 + 0.5 * np.cos(0.03 * kk)
            x_target[1] = -2 + 0.25*np.sin(0.03 * kk)
        
        elif shape_formation in ['pentagon', 'pyramid']:
            """
            center: (-1,-1); major axis:0.5 ;minor axis:0.25
            """
            x_target[0] = -1 +  0.5*np.cos(0.03*kk)
            x_target[1] = -1 +  0.25*np.sin(0.03*kk)

        elif shape_formation in ['cube','pentagonalprism']: 
            """
            center: (-2,2); major axis:0.5 ;minor axis:0.25
            """
            x_target[0] = -2 +  0.5*np.cos(0.03*kk) 
            x_target[1] = 2 +  0.25*np.sin(0.03*kk)

        else:
            x_target[0] = -1 +  0.5*np.cos(0.03*kk) 
            x_target[1] = 2 +  0.25*np.sin(0.03*kk)

        # if we chose a 2D formation the target point will be on the plane 
        if shape_formation in ['pentagon', 'square', 'A']:
            x_target[2] = 0
        else:
            x_target[2] = 2

    elif trajectory_target == 'line':
        """
        P1=(0,3) P2=(2,3)
        """
        # we can chose different type of line 
        if True:
             # P1=(0,3) P2=(2,3)
             x_target[0] = 0.001 *kk*(2)
             x_target[1] = 3+0.001 *kk*(0)
             x_target[2] = 0.0
        else:
             # center: the origin (0,0)
             x_target[0] = 0.001 * kk
             x_target[1] = 0.001 * kk
             x_target[2] = 0.0
    else:
        print("Invalid trajectory target")
        return None

    return x_target

###################################################

def writer(file_name, string):
    """
    =============================
      inner function for logging
    =============================
    """
    file = open(file_name, "a") # "a" is for append
    file.write(string)
    file.close()

#####################################################

class Agent(Node):
    def __init__(self):

        # To define the parameters in the launch file we add two flags 
        # to the constructor
        super().__init__('agent',
                            allow_undeclared_parameters=True,
                            automatically_declare_parameters_from_overrides=True)
            
        # Get parameters from launch file
        # We use the function get_parameter(), we extract the value with .value 
        # and we give the value to the local variable self...
        
        self.agent_id = self.get_parameter('agent_id').value
        self.leader_id = self.get_parameter('id_leader_formation').value
        self.neigh = self.get_parameter('neigh').value

        self.dist = self.get_parameter('dist').value
        self.dist_ii = np.array(self.dist) # it returns an n_x by 1 array

        x_i = self.get_parameter('x_init').value # state
        self.n_x = len(x_i)
        self.x_i = np.array(x_i) # it returns an n_x by 1 array

        # leader/follower parameters + obstacle 
        self.shape_formation = self.get_parameter('shape_formation').value
        # target
        x_target=self.get_parameter('target_position').value # position target point 
        self.x_target = np.array(x_target) # it returns an n_x by 1 array
        self.target_type=self.get_parameter('target_type').value # type of target point
        # obstacle
        x_obs = self.get_parameter('x_obst').value
        self.x_obs = np.array(x_obs)

        self.kk = 0 # current iteration of the agent
        self.max_iters = self.get_parameter('max_iters').value

        self.communication_time = self.get_parameter('communication_time').value 

        #######################################################################################################
        # create logging file
        self.file_name = "_csv_file_obstacle_avoidance/simulation/agent_{}.csv".format(self.agent_id)
        file = open(self.file_name, "w+") # 'w+' needs to create file and open in writing mode if doesn't exist
        file.close()
        ########################################################################################################

        ########################################################################################################
        # create logging file for the target point (for leader) 
        self.file_name3 = "_csv_file_obstacle_avoidance/target/target_agent_{}.csv".format(self.agent_id)
        file = open(self.file_name3, "w+") # 'w+' needs to create file and open in writing mode if doesn't exist
        file.close()
        #########################################################################################################       

        #########################################################################################################
        # create logging file for the obstacle barrier force
        self.file_name4 = "_csv_file_obstacle_avoidance/barrier_obst/barrier_agent_{}.csv".format(self.agent_id)
        file = open(self.file_name4, "w+") # 'w+' needs to create file and open in writing mode if doesn't exist
        file.close()
        #########################################################################################################

        ########################################################################################################
        # create logging file for the obstacle point
        self.file_name5 = "_csv_file_obstacle_avoidance/obst/obst_agent_{}.csv".format(self.agent_id)
        file = open(self.file_name5, "w+") # 'w+' needs to create file and open in writing mode if doesn't exist
        file.close()
        #########################################################################################################       


        # ** SUBSCRIBER PART **
        # Each agent must subscribe to the topic of his neighbors. To do this we create a subscription to each of 
        # the neighbors topics(self.neigh is the list of the neighbors).

        # initialize subscription dict
        self.subscriptions_list = {}

        # create a subscription to each neighbor
        for j in self.neigh:
            topic_name = '/topic_{}'.format(j)
            self.subscriptions_list[j] = self.create_subscription(
                                        MsgFloat, 
                                        topic_name, #  topic_name
                                        lambda msg, node = j: self.listener_callback(msg, node), 
                                        10)
        

        # ** PUBLISHER PART **
        ###############################################################
        # create the publisher
        self.publisher_ = self.create_publisher(
                                            MsgFloat, 
                                            f'/topic_{self.agent_id}',
                                            10)
        
        self.target_publisher = self. create_publisher(MsgFloat,
                                                       '/target_topic',
                                                       10)
        
        self.obstacle_publisher = self. create_publisher(MsgFloat,
                                                       '/obstacle_topic',
                                                       10)
        ################################################################

        # We have to trigger the publish event
        timer_period = 4 # [seconds]
        self.timer = self.create_timer(timer_period, self.timer_callback) # create a timer
        
        # initialize a dictionary with a list of received messages from each neighbor j [a queue]
        self.received_data = { j:[] for j in self.neigh } # we collect the data we receive
        # received_data is our buffer 

        print(f"Setup of agent {self.agent_id} completed")


   ########################################################################################### 
    # We define the listener_callback. Function that is called every time we receive a message.
    # listener_callback elaborate the receive message on a given topic
    # and store the message inside the buffer (in the receive message)
    def listener_callback(self, msg,node):
        self.received_data[node].append(list(msg.data))


   ########################################################################################
    # the timer_callback create the update message. Inside that function we perform consensus 
    def timer_callback(self):
        #################################################################################
        # target msg
        self.x_target = generate_trajectory(self.shape_formation,self.target_type,self.kk)
        target_msg = MsgFloat()
        target_msg.data = list(map(float, self.x_target))
        self.target_publisher.publish(target_msg)
        ##################################################################################
        #########################################################
        # Writing chosen target on the cvs file
        string_to_write = ",".join(map(str, self.x_target)) + "\n"
        writer(self.file_name3, string_to_write)
        #########################################################

        #############################################
        # obst msg
        obst_msg = MsgFloat()
        obst_msg.data = list (map(float, self.x_obs))
        self.obstacle_publisher.publish(obst_msg)
        #############################################
        #####################################################
        # Writing chosen obstacle position on the cvs file
        string_to_write = ",".join(map(str, self.x_obs)) + "\n"
        writer(self.file_name5, string_to_write)
        ######################################################

        # Skip the first iteration
        if self.kk > 0: 
            # Have all messages at time kk-1 been received? Check top message in each queue
            all_received = all(self.kk-1 == self.received_data[j][0][0] for j in self.neigh) # True if all True
            if all_received:
                # update the local state
                DeltaT = self.communication_time/10
                self.x_i, barrier = formation_update_obst(DeltaT, self.x_i, self.neigh, self.received_data, self.dist_ii,self.agent_id,self.leader_id,self.x_target,self.x_obs)
                
                #####################################################
                # save data obstacle barrier force (potential) on csv file
                barrier_values_str = ", ".join(map(str, barrier))
                string_to_write = barrier_values_str + "\n"
                writer(self.file_name4, string_to_write)
                #####################################################


                # Stop the node if kk exceeds the maximum iteration
                if self.kk > self.max_iters:
                    print("\nMAXITERS reached")
                    sleep(3) # [seconds]
                    self.destroy_node()

        # Publish the updated message
        msg = MsgFloat()
        msg.data = [float(self.kk)]
        [msg.data.append(float(element)) for element in self.x_i]
        self.publisher_.publish(msg) # we send the message 

        # save on file
        data_for_csv = msg.data.tolist().copy()
        data_for_csv = [str(round(element,4)) for element in data_for_csv[1:]]
        data_for_csv = ','.join(data_for_csv)
        writer(self.file_name,data_for_csv+'\n')

        string_for_logger = [round(i,4) for i in msg.data.tolist()[1:]]
        print("Iter = {} \t Value = {}".format(int(msg.data[0]), string_for_logger))
        # update iteration counter
        self.kk += 1

def main(args=None): # main function
    rclpy.init(args=args) # we start with the initialization of the ROS2 environment 
                 #(it is a standard)

    agent = Agent() # we create our agent (instantiation of the object)
    # Agent = name of the class that calls the init method. send a message on the channel
    # and just wait for your neighbors to sign up.

    # we print on terminal some informations
    agent.get_logger().info(f"Agent {agent.agent_id:d} -- Waiting for sync...")
    sleep(1)
    agent.get_logger().info("GO!")

    try:
        rclpy.spin(agent)
    except KeyboardInterrupt:
        agent.get_logger().info("----- Node stopped cleanly -----")
    finally:
        rclpy.shutdown() 

if __name__ == '__main__':
    main()