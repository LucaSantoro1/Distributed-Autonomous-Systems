
""""
=========================================================================================================
                                    DISTRIBUTED AUTONOMOUS SYSTEM
=========================================================================================================
Group 11
Santoro Luca, 0001005415
Spennato Armando, 0001006172

Professor: Giuseppe Notarstefano   Tutor: Ivano Notarnicola  Tutor: Lorenzo Picherri
=========================================================================================================
                        TASK 2: Formation Control 
=========================================================================================================
"""

import rclpy
from rclpy.node import Node               # Node method for Ros2
from visualization_msgs.msg import Marker # We toke Marker
from geometry_msgs.msg import Pose        # we toke Pose
from std_msgs.msg import Float32MultiArray as msg_float

class Visualizer(Node):

    def __init__(self):
        # We call the node visualizer
        super().__init__('visualizer',
                            allow_undeclared_parameters=True,
                            automatically_declare_parameters_from_overrides=True)
        
        # Get parameters from launcher
        self.agent_id = self.get_parameter('agent_id').value
        self.node_frequency = self.get_parameter('node_frequency').value

        # for leader_follower task 
        self.id_leader_formation =self.get_parameter('id_leader_formation').value

        #######################################################################################
        # Let's subscribe to the topic we want to visualize
        
        self.subscription = self.create_subscription(
                                                     msg_float, 
                                                     '/topic_{}'.format(self.agent_id),
                                                     self.listener_callback, 
                                                     10)

        #######################################################################################

        # We have to communicate with Rviz, we do that with another topic /visualization topic, 
        # that is unique with all the agents 
        # We use the Marker as kind of message

        # Create the publisher that will communicate with Rviz
        self.timer = self.create_timer(1.0/self.node_frequency, self.publish_data)
        
        self.publisher = self.create_publisher(
                                                Marker, 
                                                '/visualization_topic', 
                                                1)

        # in order to visualize  agent_id on Rviz simulation
        self.publisher_text = self.create_publisher(
                                                     Marker,
                                                    '/visualization_text_topic',
                                                    1)

        # in order to visualize barrier sfere on Rviz simulation
        self.publisher_sphere = self.create_publisher(
                                                        Marker, 
                                                        '/visualization_sphere_topic', 
                                                    1)

        # Initialize the current_pose method (in this example you can also use list or np.array)                                         
        # We chose to unitialize the current pose as a Pose message
        self.current_pose = Pose()
        # Pose() is usefull because when we want to communicate with Rviz is simple
        # to associate the current pose to the marker pose


    def listener_callback(self, msg):
        # store (and rearrange) the received message

        # The message is buid as time, x coordinate,y cordinate
        self.current_pose.position.x = msg.data[1]
        self.current_pose.position.y = msg.data[2]
        self.current_pose.position.z = msg.data[3] # to consider the third dimention


    def publish_data(self):
        if self.current_pose.position is not None:
            # If current pose is pubblished, we send to rviz somethings
            # Set the type of message to send to Rviz -> Marker
            # (see http://docs.ros.org/en/noetic/api/visualization_msgs/html/index-msg.html)
            marker = Marker()

            # Select the name of the reference frame, without it markers will be not visualized
            marker.header.frame_id = 'my_frame' # Is a refer system for the object that will be visualized in Rviz
            marker.header.stamp = self.get_clock().now().to_msg()

            # Select the type of marker
            # marker.type = Marker.SPHERE
            marker.type = Marker.MESH_RESOURCE


            marker.mesh_resource = "package://formation_control/meshes/das_quadcopter2.stl"


            # set the pose of the marker (orientation is omitted in this example)
            marker.pose.position.x = self.current_pose.position.x
            marker.pose.position.y = self.current_pose.position.y
            marker.pose.position.z = self.current_pose.position.z 

            # Select the marker action (ADD, DELATE)
            marker.action = Marker.ADD

            # We separate the marker informations:
            # Select the namespace of the marker
            marker.ns = 'agents'

            # Let the marker be unique by setting its id
            marker.id = self.agent_id

            # Specify the scale of the marker (geometric staff)
            # for mavic 0.005
            scale = 0.01
            marker.scale.x = scale
            marker.scale.y = scale
            marker.scale.z = scale
            
            
            # Specify the color of the marker as RGBA
            color = [1.0, 0.0, 0.0, 1.0]

            if self.agent_id == self.id_leader_formation:
                color = [0.0, 0.0, 1.0, 1.0] # blue
            else:
                if self.agent_id % 2: #dispari
                    color = [0.0, 1.0, 0.0, 1.0] #green
                    
            marker.color.r = color[0]
            marker.color.g = color[1]
            marker.color.b = color[2]
            marker.color.a = color[3]


            #####################################################################################
            # Second marker for displaying tha agent id
            text_marker = Marker()
            text_marker.header.frame_id = 'my_frame'
            text_marker.header.stamp = self.get_clock().now().to_msg()
            text_marker.type = Marker.TEXT_VIEW_FACING
            text_marker.pose.position.x = self.current_pose.position.x
            text_marker.pose.position.y = self.current_pose.position.y
            text_marker.pose.position.z = self.current_pose.position.z + 0.2  # Altezza sopra la mesh
            text_marker.action = Marker.ADD
            text_marker.ns = 'agents_text'
            text_marker.id = self.agent_id
            text_marker.scale.z = 0.2  # Altezza del testo
            text_marker.color.r = 0.0
            text_marker.color.g = 0.0
            text_marker.color.b = 0.0
            text_marker.color.a = 1.0
            text_marker.text  = str(self.agent_id)

            self.text_marker = text_marker

            ###########################################################################################
            # Third marker to display the barrier sfere
            # Sphere Marker
            sphere_marker = Marker()
            sphere_marker.header.frame_id = 'my_frame'
            sphere_marker.header.stamp = self.get_clock().now().to_msg()
            sphere_marker.type = Marker.SPHERE
            

            # Ensure sphere_radius is a float
            sphere_radius = 0.75 # Set your desired radius here, as a float

            # Set the scale of the sphere (represents diameter)
            sphere_marker.scale.x = float(sphere_radius * 2)
            sphere_marker.scale.y = float(sphere_radius * 2)
            sphere_marker.scale.z = float(sphere_radius * 2)

            # Set the color and transparency of the sphere
            sphere_marker.color.r = 0.5
            sphere_marker.color.g = 0.5
            sphere_marker.color.b = 0.5
            sphere_marker.color.a = 0.1  # Adjust alpha for transparency

            # Set the position of the sphere to the current position of the drone
            sphere_marker.pose.position.x = self.current_pose.position.x
            sphere_marker.pose.position.y = self.current_pose.position.y
            sphere_marker.pose.position.z = self.current_pose.position.z

            sphere_marker.action = Marker.ADD
            sphere_marker.ns = 'agent_spheres'
            sphere_marker.id = self.agent_id
            
            #########################################################################################
            # Let's publish the marker
            self.publisher.publish(marker)
            # Let's publish the text marker
            self.publisher_text.publish(text_marker)
            # Let's publish the barrier sfere marker
            self.publisher_sphere.publish(sphere_marker) 


# General way to spin the node 
def main():
    rclpy.init() # we inizialize Ros

    visualizer = Visualizer() # then we spin our visualizer

    try:
        rclpy.spin(visualizer)
    except KeyboardInterrupt:
        print("----- Visualizer stopped cleanly -----")
    finally:
        rclpy.shutdown() 

if __name__ == '__main__':
    main()