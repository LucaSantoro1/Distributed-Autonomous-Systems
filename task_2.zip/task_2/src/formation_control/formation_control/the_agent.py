""""
=========================================================================================================
                         DISTRIBUTED AUTONOMOUS SYSTEM 
=========================================================================================================
Group 11
Santoro Luca, 0001005415
Spennato Armando, 0001006172

Professor: Giuseppe Notarstefano   Tutor: Ivano Notarnicola  Tutor: Lorenzo Picherri
=========================================================================================================
                        TASK 2: Formation Control 
=========================================================================================================
"""

from time import sleep
import numpy as np 
import rclpy # we use ROS2 Python implementation
from rclpy.node import Node # take the Node class
from std_msgs.msg import Float32MultiArray as MsgFloat # because we want to use numbers (array of float number)

def formation_update(dt, x_i, neigh, data, dist):
    """
    ========================================================================================
     This function updates the state of an agent in a formation control system using a simple
     Euler integration scheme. It implements a formation control law where the agent adjusts 
     its position based on the positions of its neighbors. In particular, the function iterates
     over the neighbors, calculates a potential function dV_ij based on the difference in 
     positions, and updates the agent's state (x_i) using the Euler integration method.
            Inputs:    
                    dt    = discretization step
                    x_i   = state of agent i
                    neigh = list of neihbors
                    data  = state of neighbors
                    dist  = distance for formation control law 
            Output: x_i   = state of agent i
                    potential = list where we store the potential values
    =========================================================================================
    """
    xdot_i = np.zeros(x_i.shape)
    

    potential_values = [] 
    for j in neigh:
        x_j = np.array(data[j].pop(0)[1:])
        dV_ij = ((x_i - x_j).T@(x_i - x_j) - dist[j]**2)*(x_i - x_j)
        
        xdot_i += - dV_ij

        potential_value = np.linalg.norm(dV_ij)
        potential_values.append(potential_value)

    # Forward Euler
    x_i += dt*xdot_i

    return x_i,potential_values

def writer(file_name, string):
    """
    =============================
    inner function for logging
    =============================
    """
    file = open(file_name, "a") # "a" is for append
    file.write(string)
    file.close()

class Agent(Node):
    def __init__(self):

        # To define the parameters in the launch file we add two flags 
        # to the constructor
        super().__init__('agent',
                            allow_undeclared_parameters=True,
                            automatically_declare_parameters_from_overrides=True)
            
        # Get parameters from launch file
        # We use the function get_parameter(), we extract the value with .value 
        # and we give the value to the local variable self...
        
        self.agent_id = self.get_parameter('agent_id').value
        self.neigh = self.get_parameter('neigh').value

        self.dist = self.get_parameter('dist').value
        self.dist_ii = np.array(self.dist) # it returns an n_x by 1 array

        x_i = self.get_parameter('x_init').value # state
        self.n_x = len(x_i)
        self.x_i = np.array(x_i) # it returns an n_x by 1 array

        self.kk = 0 # current iteration of the agent
        self.max_iters = self.get_parameter('max_iters').value

        self.communication_time = self.get_parameter('communication_time').value 

        ######################################################################################################
        # create logging file
        self.file_name = "_csv_file_formation/simulation/agent_{}.csv".format(self.agent_id)
        file = open(self.file_name, "w+") # 'w+' needs to create file and open in writing mode if doesn't exist
        file.close()
        #######################################################################################################
        #######################################################################################################
        # create logging file for the the distances
        self.file_name2 = "_csv_file_formation/distance/distance_agent_{}.csv".format(self.agent_id)
        file = open(self.file_name2, "w+") # 'w+' needs to create file and open in writing mode if doesn't exist
        file.close()
        #######################################################################################################
        #######################################################################################################
        # create logging file for formation potential (force)
        self.file_name3 = "_csv_file_formation/potential/potential_agent_{}.csv".format(self.agent_id)
        file = open(self.file_name3, "w+") # 'w+' needs to create file and open in writing mode if doesn't exist
        file.close()
        #######################################################################################################

        #####################################################
        # Writing desired distance on the cvs file
        string_to_write = ",".join(map(str, self.dist)) + "\n"
        writer(self.file_name2, string_to_write)
        #####################################################


        # ** SUBSCRIBER PART **
        # Each agent must subscribe to the topic of his neighbors. To do this we create a subscription to each of 
        # the neighbors topics(self.neigh is the list of the neighbors).

        # initialize subscription dict
        self.subscriptions_list = {}

        # create a subscription to each neighbor
        for j in self.neigh:
            topic_name = '/topic_{}'.format(j)
            self.subscriptions_list[j] = self.create_subscription(
                                        MsgFloat, 
                                        topic_name, #  topic_name
                                        lambda msg, node = j: self.listener_callback(msg, node), 
                                        10)
        

        # ** PUBLISHER PART **
        # create the publisher
        self.publisher_ = self.create_publisher(
                                            MsgFloat, 
                                            f'/topic_{self.agent_id}',
                                            10)
        
        
        # We have to trigger the publish event
        timer_period = 4 # [seconds]
        self.timer = self.create_timer(timer_period, self.timer_callback) # create a timer
        

        # initialize a dictionary with a list of received messages from each neighbor j [a queue]
        self.received_data = { j:[] for j in self.neigh } # we collect the data we receive
        # received_data is our buffer 

        print(f"Setup of agent {self.agent_id} completed")


   ########################################################################################### 
    # We define the listener_callback. Function that is called every time we receive a message.
    # listener_callback elaborate the receive message on a given topic
    # and store the message inside the buffer (in the receive message)
    def listener_callback(self, msg,node):
        self.received_data[node].append(list(msg.data))

   ########################################################################################
    # the timer_callback create the update message. Inside that function we perform consensus 
    def timer_callback(self):
        # Initialize a message of type float
        msg = MsgFloat()
        # **1) Take message from Buffer
        if self.kk == 0: # Let the publisher start at the first iteration
            msg.data = [float(self.kk)]
            [msg.data.append(float(element)) for element in self.x_i]
            self.publisher_.publish(msg) # we send the message 

            self.kk += 1

            # log files
            # 1) visualize on the terminal
            string_for_logger = [round(i,4) for i in msg.data.tolist()[1:]]
            print("Iter = {} \t Value = {}".format(int(msg.data[0]), string_for_logger))

            # 2) save on file
            data_for_csv = msg.data.tolist().copy()
            data_for_csv = [str(round(element,4)) for element in data_for_csv[1:]]
            data_for_csv = ','.join(data_for_csv)
            writer(self.file_name,data_for_csv+'\n')

        else: 
            # Check if lists are nonempty and then we perform the update 
            all_received = all(self.received_data[j] for j in self.neigh) # check if all neighbors' have been received

            # all is a logic function, used to check if all the elements in its argument are TRUE (one no TRUE ==> FALSE)
            sync = False
            # Have all messages at time t-1 arrived?
            if all_received:
                sync = all(self.kk-1 == self.received_data[j][0][0] for j in self.neigh) # True if all True

            if sync:
                DeltaT = self.communication_time/10
                # update the local state
                self.x_i, potential = formation_update(DeltaT, self.x_i, self.neigh, self.received_data, self.dist_ii)
                
                #**2) Publish the updated message 
                # publish the updated message
                msg.data = [float(self.kk)]
                [msg.data.append(float(element)) for element in self.x_i]
                self.publisher_.publish(msg)

                # save data on csv file
                data_for_csv = msg.data.tolist().copy()
                data_for_csv = [str(round(element,4)) for element in data_for_csv[1:]]
                data_for_csv = ','.join(data_for_csv)
                writer(self.file_name,data_for_csv+'\n')

                #####################################################
                # save data potential on csv file
                potential_values_str = ", ".join(map(str, potential))
                string_to_write = potential_values_str + "\n"
                writer(self.file_name3, string_to_write)
                #####################################################

                string_for_logger = [round(i,4) for i in msg.data.tolist()[1:]]
                print("Iter = {} \t Value = {}".format(int(msg.data[0]), string_for_logger))
                
                # Stop the node if kk exceeds MAXITERS
                if self.kk > self.max_iters:
                    print("\nMAXITERS reached")
                    sleep(3) # [seconds]
                    self.destroy_node()

                # update iteration counter
                self.kk += 1



def main(args=None): # main function
    rclpy.init(args=args) # we start with the initialization of the ROS2 environment 
                 #(it is a standard)

    agent = Agent() # we create our agent (instantiation of the object)
    # Agent = name of the class that calls the init method. send a message on the channel
    # and just wait for your neighbors to sign up.

    # we print on terminal some informations
    agent.get_logger().info(f"Agent {agent.agent_id:d} -- Waiting for sync...")
    sleep(1)
    agent.get_logger().info("GO!")

    try:
        rclpy.spin(agent)
    except KeyboardInterrupt:
        agent.get_logger().info("----- Node stopped cleanly -----")
    finally:
        rclpy.shutdown() 

if __name__ == '__main__':
    main()