=========================================================================================================
                                      DISTRIBUTED AUTONOMOUS SYSTEM 
=========================================================================================================
Group 11
Santoro Luca, 0001005415
Spennato Armando, 0001006172

Professor: Giuseppe Notarstefano   Tutor: Ivano Notarnicola  Tutor: Lorenzo Picherri
=========================================================================================================
                                README Task 2: Formation Control
=========================================================================================================

This README is related to the second Task of the Assignment course project.
---------------------------------------------------------------------------------------------------------
All the files related to the Task 2 are stored inside the folder task_2. The project is organized as follow:

Initial steps:

1)  Compiling the package:
From the root of the workspace (task_2 folder) use the command: 
• colcon build --symlink-install
After a successful build, the following directories should appear
DAS_ros2_files/build
DAS_ros2_files/install
DAS_ros2_files/log

2) Now we are ready to run the launch files. From task_2 folder
• Execute source /opt/ros/foxy/setup.bash
• Execute . install/setup.bash
 2.1) In the project there is the possibility to choose between different shapes for the formation 
      (pentagon, square, cube, pyramid, pentagonal prism, A), consequently the number of agents will also change.
    To choose the formation execute:
                • export shape_formation=...(choosen formation) 
    
 
#########################
Task 2.1 - Problem Set-up
#########################

• ros2 launch formation_control formations.launch.py

*NOTE* : the shape_formation is setting from default to cube.

##############################
Task 2.2 - Collision Avoidance
##############################

• ros2 launch formation_control collision.launch.py

To force the collision:
 - set the barrier_proof flag to TRUE in the collision.launch.py in order to change the initialization
 - disable the barrier function within the update formation_formation function inside the collision.agent.py file
*NOTE*: The inizialization to force the collision is provided only for square formation.
*NOTE* : the shape_formation is setting from default to square.

##############################################
Task 2.3 - Moving formation and leader Control
##############################################

• ros2 launch formation_control leader_follower.launch.py

We implement only one leader.
In the project there is the possibility to choose between different types of targets for the formation 
(point,circle,ellipse,line), consequently the trajectory of the leader agent will change.
To choose the target type execute:
                • export target_type=...(choosen target)

*NOTE* : the target type is setting from default to point.

########################################
(optional) Task 2.4 - Obstacle avoidance
########################################

• ros2 launch formation_control obstacle.launch.py

*NOTE* : the shape_formation is setting from default to square.
*NOTE* : the target type is setting from default to point. 
(The other types are not considered for this exercise)

#######################
_csv_file_ organization
#######################
In task_2 folder there are different files: plot_csv_FORMATION, plt_csv_COLLISION, plot_csv_LEADER_FOLLOWER, plot_csv_OBSTACLE_AVOIDANCE.

In each file there is the possibility to choose the folder from which to take the data: default and simulation.

default: folder containing previously saved data
simulation: data from the current Rviz simulation

(this was done because if the number of agents increases the simulation time increases, 
in this way we can view as many simulations as possible during the exam)

Furthermore in each file there is the possibility to specify the shape of the formation 
(plot_csv_FORMATION) and the type of target (plot_csv_LEADER_FOLLOWER)

Each one is related to a point of the Task 2 of the project assignment. By running this file at the end of the ROS2 simulation (so as
to fill the _cvs_file folder), we obtain graphs and animations useful for better understanding the formations 
and trajectories of the agents.